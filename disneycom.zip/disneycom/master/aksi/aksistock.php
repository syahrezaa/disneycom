<?php
	include "../../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	if($_GET['act']=='update'){
		mysql_query("UPDATE stock SET nameMerek = '$_GET[nameMerek]'
									WHERE idMerek = '$_GET[idMerek]'");
			
													
	
		echo"<script>
			location.assign('?mod=dashboard');
		</script>";
	exit;
	}elseif($_GET['act']=='hapus'){
		mysql_query("DELETE FROM stock WHERE idMerek = '$_GET[idMerek]'");
		
		echo"<script>
			location.assign('?mod=dashboard');
		</script>";
		exit;
	}elseif($_GET['act']=='insert'){
		$cekstock = mysql_fetch_array(mysql_query("SELECT * FROM stock WHERE stock.idBarang = '$_GET[idBarang]' ORDER BY idStock DESC LIMIT 1"));
		$saldo = $cekstock['saldoStock'] + $_GET['masukStock'];
		$masuk = $cekstock['masukStock'] + $_GET['masukStock'];
		
		if($cekstock['idBarang']==''){
			mysql_query("INSERT INTO stock(
										idBarang,
										masukStock,
										keluarStock,
										saldoStock
									)VALUES(
										'$_GET[idBarang]',
										'$masuk',
										'0',
										'$saldo'
										
									)");
									
		}else{
			mysql_query("UPDATE stock SET masukStock = '$masukStock', saldoStock = '$saldo' WHERE idStock = '$cekstock[idStock]'");
		}		
		
		echo"<script>
				location.reload();
			</script>";
		exit;
	}
	

?>