<?php
	include "../../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	if($_GET['act']=='update'){
		$img = md5("$_GET[passwordUser]");
		mysql_query("UPDATE user SET nameUser = '$_GET[nameUser]',
										usernameUser = '$_GET[usernameUser]',
										emailUser = '$_GET[emailUser]',
										passwordUser = '$img'
									WHERE idUser = '$_GET[idUser]'");
			
		
		echo"<script>
			location.assign('?mod=user');
		</script>";
	exit;
	}elseif($_GET['act']=='hapus'){
		mysql_query("DELETE FROM user WHERE idUser = '$_GET[idUser]'");
		
		echo"<script>
			location.assign('?mod=user');
		</script>";
		exit;
	}elseif($_GET['act']=='insert'){
		$img=md5("$_GET[passwordUser]");
		mysql_query("INSERT INTO user(
										nameUser,
										passwordUser,
										usernameUser,
										emailUser
									)VALUES(
										'$_GET[nameUser]',
										'$img',
										'$_GET[usernameUser]',
										'$_GET[emailUser]'
									)");
									
													
		
		echo"<script>
				location.reload();
			</script>";
		exit;
	}
	

?>