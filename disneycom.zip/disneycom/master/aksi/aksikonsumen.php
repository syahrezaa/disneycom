<?php
	include "../../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	if($_GET['act']=='hapus'){
		mysql_query("DELETE FROM customer WHERE idCustomer = '$_GET[idCustomer]'");
		
		echo"<script>
			location.assign('?mod=konsumen');
		</script>";
		exit;
	}
	

?>