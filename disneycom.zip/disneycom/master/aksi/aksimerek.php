<?php
	include "../../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	if($_GET['act']=='update'){
		mysql_query("UPDATE merek SET nameMerek = '$_GET[nameMerek]'
									WHERE idMerek = '$_GET[idMerek]'");
			
													
	
		echo"<script>
			location.assign('?mod=dashboard');
		</script>";
	exit;
	}elseif($_GET['act']=='hapus'){
		mysql_query("DELETE FROM merek WHERE idMerek = '$_GET[idMerek]'");
		
		echo"<script>
			location.assign('?mod=dashboard');
		</script>";
		exit;
	}elseif($_GET['act']=='insert'){
		mysql_query("INSERT INTO merek(
										nameMerek
									)VALUES(
										'$_GET[nameMerek]'
									)");
									
													
		
		echo"<script>
				location.reload();
			</script>";
		exit;
	}
	

?>