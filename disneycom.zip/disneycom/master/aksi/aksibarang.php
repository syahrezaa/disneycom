<?php
	include "../../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	if($_GET['act']=='update'){
		mysql_query("UPDATE barang SET nameBarang = '$_GET[nameBarang]',
										ketBarang = '$_GET[ketBarang]',
										idMerek = '$_GET[idMerek]',
										hargaBarang = '$_GET[hargaBarang]',
										idSupplier = '$_GET[idSupplier]'
									WHERE idBarang = '$_GET[idBarang]'");
			
		if($_GET['imgBarang']<>'undefined'){
			mysql_query("UPDATE barang SET imgBarang = '$_GET[imgBarang]'
									WHERE idBarang = '$_GET[idBarang]'");
		}										
	
		echo"<script>
			location.assign('?mod=barang');
		</script>";
	exit;
	}elseif($_GET['act']=='hapus'){
		mysql_query("DELETE FROM barang WHERE idBarang = '$_GET[idBarang]'");
		
		echo"<script>
			location.assign('?mod=barang');
		</script>";
		exit;
	}elseif($_GET['act']=='insert'){
		mysql_query("INSERT INTO barang(
										nameBarang,
										imgBarang,
										ketBarang,
										idMerek,
										hargaBarang,
										idSupplier
									)VALUES(
										'$_GET[nameBarang]',
										'$_GET[imgBarang]',
										'$_GET[ketBarang]',
										'$_GET[idMerek]',
										'$_GET[hargaBarang]',
										'$_GET[idSupplier]'
									)");
									
													
		
		echo"<script>
				location.reload();
			</script>";
		exit;
	}
	

?>