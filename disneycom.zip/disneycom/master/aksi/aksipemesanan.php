<?php
	include "../../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	if($_GET['act']=='hapus'){
		mysql_query("DELETE FROM pemesanan WHERE idPemesanan = '$_GET[idPemesanan]'");
		
		echo"<script>
			location.assign('?mod=cekpesanan');
		</script>";
		exit;
	}elseif($_GET['act']=='reject'){
		mysql_query("UPDATE pemesanan  SET ketPemesanan ='$_GET[ketPemesanan]', statusPemesanan = 'Reject' WHERE idPemesanan = '$_GET[idPemesanan]'");
		
		echo"<script>
			location.assign('?mod=cekpesanan');
		</script>";
		exit;
	}
	

?>