<?php
	include "../../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	if($_GET['act']=='update'){
		mysql_query("UPDATE supplier SET nameSupplier = '$_GET[nameSupplier]',
										emailSupplier = '$_GET[emailSupplier]',
										tlpnSupplier = '$_GET[tlpnSupplier]',
										faxSupplier = '$_GET[faxSupplier]',
										alamatSupplier = '$_GET[alamatSupplier]',
										pemilikSupplier = '$_GET[pemilikSupplier]'
									WHERE idSupplier = '$_GET[idSupplier]'");
			
		
		echo"<script>
			location.assign('?mod=supplier');
		</script>";
	exit;
	}elseif($_GET['act']=='hapus'){
		mysql_query("DELETE FROM supplier WHERE idSupplier = '$_GET[idSupplier]'");
		
		echo"<script>
			location.assign('?mod=supplier');
		</script>";
		exit;
	}elseif($_GET['act']=='insert'){
		mysql_query("INSERT INTO supplier(
										nameSupplier,
										emailSupplier,
										faxSupplier,
										tlpnSupplier,
										alamatSupplier,
										pemilikSupplier
									)VALUES(
										'$_GET[nameSupplier]',
										'$_GET[emailSupplier]',
										'$_GET[faxSupplier]',
										'$_GET[tlpnSupplier]',
										'$_GET[alamatSupplier]',
										'$_GET[pemilikSupplier]'
									)");
									
													
		
		echo"<script>
				location.reload();
			</script>";
		exit;
	}
	

?>