<?php
	include "../../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	if($_GET['act']=='konfirm'){
		
		mysql_query("UPDATE pembayaran SET statusPembayaran = 'Paid' WHERE idPembayaran = '$_GET[idPembayaran]'");
		
		mysql_query("UPDATE pemesanan SET statusPemesanan = 'Paid' WHERE idPemesanan = '$_GET[idPemesanan]'");
		
		$cekpenjualan = mysql_fetch_array(mysql_query("SELECT * FROM penjualan ORDER BY idPenjualan DESC LIMIT 1"));
		$total = $cekpenjualan['totalPenjualan'] + $_GET['totalPembayaran'];
		mysql_query("INSERT INTO penjualan(
										idPembayaran,
										totalPenjualan,
										totalPembayaran,
										idUser,
										datePenjualan
									)VALUES(
										'$_GET[idPembayaran]',
										'$total',
										'$_GET[totalPembayaran]',
										'$_SESSION[idUser]',
										'$date'
									)");
		
		$cekbarang = mysql_query("SELECT * FROM detailpesanan 
									INNER JOIN pemesanan
										ON pemesanan.idPemesanan = detailpesanan.idPemesanan
									WHERE pemesanan.idPemesanan = '$_GET[idPemesanan]'");
		while($rc = mysql_fetch_array($cekbarang)){
			
			$cekstock = mysql_fetch_array(mysql_query("SELECT * FROM stock WHERE stock.idBarang = '$rc[idBarang]' ORDER BY idStock DESC LIMIT 1"));
			$saldo = $cekstock['saldoStock'] - $rc['qtyDetailpesanan'];
			$keluar = $cekstock['keluarStock'] + $rc['qtyDetailpesanan'];
			
			if($cekstock['idBarang'] == ''){
				mysql_query("INSERT INTO stock(
												idBarang,
												masukStock,
												keluarStock,
												saldoStock,
												ketStock
											)VALUES(
												'$rc[idBarang]',
												'0',
												'$keluar',
												'$saldo',
												''
											)");
			}else{
				mysql_query("UPDATE stock SET keluarStock = '$keluar', saldoStock = '$saldo' WHERE idStock = '$cekstock[idStock]'");
			}
		}
		echo"<script>
			location.assign('?mod=konfirmasi');
		</script>";
		exit;
	}elseif($_GET['act']=='kirim'){
		mysql_query("UPDATE pembayaran SET statusPembayaran = 'Pengiriman' WHERE idPembayaran = '$_GET[idPembayaran]'");
		
		mysql_query("UPDATE pemesanan SET statusPemesanan = 'Pengiriman' WHERE idPemesanan = '$_GET[idPemesanan]'");
		
		echo"<script>
			location.assign('?mod=konfirmasi');
		</script>";
		exit;
	}
	

?>