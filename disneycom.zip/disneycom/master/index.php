<!DOCTYPE html>
<?php
	session_start();
	include("../config/koneksi.php");
	$idMember = $_SESSION['idUser'];
	if($idMember==''){
		echo"<script>
			location.assign('../');
		</script>";
	}else{	
?>

<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Toko Komputer</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/half-slider.css" rel="stylesheet">
	<link href="datepicker/datepicker.css" rel="stylesheet"/>
	

</head>

<body>

   <!-- Navigation -->
    <nav class="navbar navbar-default navbar-inverse" role="navigation" style='border-radius:none;'>
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" style='color:#fff'>Toko Komputer</a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav pull-right">
                    <li>
                        <a href="logout.php" style='color:#fff'>Logout</a>
                    </li>
				
                </ul>
            </div>
        </div>
        <!-- /.container -->
    </nav>

				
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class='panel panel-default'>
					<div class='panel-heading'>
						<i class='fa fa-bar-chart-o fa-fw'></i> Menu Admin
						
					</div>
                <div class="list-group">
                    <a href="?mod=dashboard" class="list-group-item">Merek</a>
                    <a href="?mod=barang" class="list-group-item">Barang</a>
                    <a href="?mod=cekpesanan" class="list-group-item">Cek Pesanan</a>
                    <a href="?mod=konfirmasi" class="list-group-item">Konfirmasi Pembayaran</a>
                    <a href="?mod=customer" class="list-group-item">Customer</a>
                    <a href="?mod=supplier" class="list-group-item">Supplier</a>
                    <a href="?mod=penjualan" class="list-group-item">Penjualan</a>
                    <a href="?mod=stock" class="list-group-item">Stock</a>
                    <a href="?mod=user" class="list-group-item">User</a>
                    <a href="?mod=laporanpesanan" class="list-group-item">Laporan Pesanan</a>
                    <a href="?mod=laporanpembayaran" class="list-group-item">Laporan Pembayaran</a>
                    <a href="?mod=laporanpenjualan" class="list-group-item">Laporan Penjualan</a>
                </div>
				</div>
            </div>

            <div class="col-md-9">
                <div class="row">
					<?php
						if($_GET['mod']=='dashboard'){
							include"modul/home/dashboard.php";
						}elseif($_GET['mod']=='updatemerek'){
							include"modul/home/updatemerek.php";
						}elseif($_GET['mod']=='barang'){
							include"modul/barang/barang.php";
						}elseif($_GET['mod']=='updatebarang'){
							include"modul/barang/updatebarang.php";
						}elseif($_GET['mod']=='konfirmasi'){
							include"modul/konfirmasi/konfirmasi.php";
						}elseif($_GET['mod']=='customer'){
							include"modul/customer/customer.php";
						}elseif($_GET['mod']=='updatecustomer'){
							include"modul/customer/updatecustomer.php";
						}elseif($_GET['mod']=='supplier'){
							include"modul/supplier/supplier.php";
						}elseif($_GET['mod']=='updatesupplier'){
							include"modul/supplier/updatesupplier.php";
						}elseif($_GET['mod']=='user'){
							include"modul/user/user.php";
						}elseif($_GET['mod']=='updateuser'){
							include"modul/user/updateuser.php";
						}elseif($_GET['mod']=='cekpesanan'){
							include"modul/pesanan/pesanan.php";
						}elseif($_GET['mod']=='laporanpesanan'){
							include"modul/laporan/laporanpesanan.php";
						}elseif($_GET['mod']=='laporanpembayaran'){
							include"modul/laporan/laporanpembayaran.php";
						}elseif($_GET['mod']=='stock'){
							include"modul/stock/stock.php";
						}elseif($_GET['mod']=='penjualan'){
							include"modul/penjualan/penjualan.php";
						}elseif($_GET['mod']=='laporanpenjualan'){
							include"modul/laporan/laporanpenjualan.php";
						}else{
							include"modul/home/dashboard.php";
						}		
					?>
					
                </div>
            </div>

        </div>

    </div>
    <!-- /.container -->

    <div class="container">
        <hr>
        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Admin Toko Komputer</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="datepicker/js/bootstrap-datepicker.min.js"></script>
	<script>
		$(document).ready(function(){
			$('.datepicker').datepicker({
				format: 'yyyy-mm-dd',
				autoclose: true
			});
		
			$("#submituser").click(function(){
				var nameUser 	= $("#nameUser").val();
				if(nameUser==''){
					document.getElementById('nameUser').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var usernameUser 	= $("#usernameUser").val();
				if(usernameUser==''){
					document.getElementById('usernameUser').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var passwordUser 	= $("#passwordUser").val();
				if(passwordUser==''){
					document.getElementById('passwordUser').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var emailUser 	= $("#emailUser").val();
				if(emailUser==''){
					document.getElementById('emailUser').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				$.ajax({
					url: "aksi/aksiuser.php?act=insert",
					data: "nameUser=" + nameUser + "&usernameUser=" + usernameUser + "&passwordUser=" + passwordUser + "&emailUser=" + emailUser,
					success: function(data){
						$("#list_user").html(data);
					}
				});
				return false;
			});
			$("#submitupdateuser").click(function(){
				var idUser 	= $("#idUser").val();
				var nameUser 	= $("#nameUser").val();
				if(nameUser==''){
					document.getElementById('nameUser').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var usernameUser 	= $("#usernameUser").val();
				if(usernameUser==''){
					document.getElementById('usernameUser').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var passwordUser 	= $("#passwordUser").val();
				if(passwordUser==''){
					document.getElementById('passwordUser').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var emailUser 	= $("#emailUser").val();
				if(emailUser==''){
					document.getElementById('emailUser').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				$.ajax({
					url: "aksi/aksiuser.php?act=update",
					data: "nameUser=" + nameUser + "&usernameUser=" + usernameUser + "&passwordUser=" + passwordUser + "&emailUser=" + emailUser + "&idUser=" + idUser,
					success: function(data){
						$("#list_user").html(data);
					}
				});
				return false;
			});
			$(".hapususer").click(function(){
				var idUser 	= $(this).attr("idUser");
				var result = confirm("hapus user?");
				if (result) {
				
					$.ajax({
						url: "aksi/aksiuser.php?act=hapus",
						data: "idUser=" + idUser,
						success: function(data){
							location.reload();
						}
					});
					return false;
				}
			});
			$(".hapuspesanan").click(function(){
				var idPemesanan 	= $(this).attr("idPemesanan");
				var ketPemesanan 	= $("#ketPemesanan").val();
				
				$.ajax({
					url: "aksi/aksipemesanan.php?act=reject",
					data: "idPemesanan=" + idPemesanan + "&ketPemesanan=" + ketPemesanan,
					success: function(data){
						location.reload();
					}
				});
				return false;
			});
		
			$("#submitmerek").click(function(){
				var nameMerek 	= $("#nameMerek").val();
				if(nameMerek==''){
					document.getElementById('nameMerek').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				$.ajax({
					url: "aksi/aksimerek.php?act=insert",
					data: "nameMerek=" + nameMerek,
					success: function(data){
						$("#list_merek").html(data);
					}
				});
				return false;
			});
			$("#submitupdatemerek").click(function(){
				var idMerek 	= $("#idMerek").val();
				var nameMerek 	= $("#nameMerek").val();
				if(nameMerek==''){
					document.getElementById('nameMerek').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				$.ajax({
					url: "aksi/aksimerek.php?act=update",
					data: "nameMerek=" + nameMerek + "&idMerek=" + idMerek,
					success: function(data){
						$("#list_merek").html(data);
					}
				});
				return false;
			});
			$(".hapusmerek").click(function(){
				var idMerek 	= $(this).attr("idMerek");
				var result = confirm("hapus Merek?");
				if (result) {
				
					$.ajax({
						url: "aksi/aksimerek.php?act=hapus",
						data: "idMerek=" + idMerek,
						success: function(data){
							location.reload();
						}
					});
					return false;
				}
			});
			
			
			$("#submitbarang").click(function(){
				var idMerek 	= $("#idMerek").val();
				var idSupplier 	= $("#idSupplier").val();
				var nameBarang 	= $("#nameBarang").val();
				if(nameBarang==''){
					document.getElementById('nameBarang').style.border ='2px solid red';
					e.preventDefault(); 
				}	
				var ketBarang 	= $("#ketBarang").val();
				if(ketBarang==''){
					document.getElementById('ketBarang').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var hargaBarang 	= $("#hargaBarang").val();
				if(hargaBarang==''){
					document.getElementById('hargaBarang').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				var imgBarang 	= $("#imgBarang").val();
				$.ajax({
					url: "aksi/aksibarang.php?act=insert",
					data: "nameBarang=" + nameBarang + "&idMerek=" + idMerek + "&ketBarang=" + ketBarang + "&imgBarang=" + imgBarang + "&hargaBarang=" + hargaBarang + "&idSupplier=" + idSupplier,
					success: function(data){
						$("#list_barang").html(data);
					}
				});
				return false;
			});
			$("#submitupdatebarang").click(function(){
				var idBarang 	= $("#idBarang").val();
				var idSupplier 	= $("#idSupplier").val();
				var idMerek 	= $("#idMerek").val();
				var nameBarang 	= $("#nameBarang").val();
				if(nameBarang==''){
					document.getElementById('nameBarang').style.border ='2px solid red';
					e.preventDefault(); 
				}	
				var ketBarang 	= $("#ketBarang").val();
				if(ketBarang==''){
					document.getElementById('ketBarang').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var hargaBarang 	= $("#hargaBarang").val();
				if(hargaBarang==''){
					document.getElementById('hargaBarang').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				
				var imgBarang 	= $("#imgBarang").val();
				$.ajax({
					url: "aksi/aksibarang.php?act=update",
					data: "nameBarang=" + nameBarang + "&idMerek=" + idMerek + "&ketBarang=" + ketBarang + "&imgBarang=" + imgBarang + "&idBarang=" + idBarang + "&hargaBarang=" + hargaBarang + "&idSupplier=" + idSupplier,
					success: function(data){
						$("#list_barang").html(data);
					}
				});
				return false;
			});
			
			$(".hapuscatalog").click(function(){
				var idBarang 	= $(this).attr("idBarang");
				var result = confirm("hapus katalog?");
				if (result) {
				
					$.ajax({
						url: "aksi/aksibarang.php?act=hapus",
						data: "idBarang=" + idBarang,
						success: function(data){
							location.reload();
						}
					});
					return false;
				}
			});
			
			
		$('#files').change(function() {
			function _(el){
				return document.getElementById(el);
			}
			
			var file = _("files").files[0];
			if(file.size > 5500000){
				alert("Maksimum File Upload 5 MB");
				e.preventDefault();
			}
			
			
				if(file.name==''){
					alert("File masih kosong");
				}else{
					var formdata = new FormData();
					formdata.append("files", file);
					var ajax = new XMLHttpRequest();
					ajax.upload.addEventListener("progress", progressHandler, false);
					ajax.addEventListener("load", completeHandler, false);
					ajax.addEventListener("error", errorHandler, false);
					ajax.addEventListener("abort", abortHandler, false);
					ajax.open("POST", "aksi/uploadfoto.php");
					ajax.send(formdata);
					 
					$('#progressupload').show(); 
				}
			
				function progressHandler(event){
					_("loaded_n_total").innerHTML = "";
					var percent = (event.loaded / event.total) * 100;
					_("progressBar").value = Math.round(percent);
					_("status").innerHTML = "";
					
				}
				function completeHandler(event){
					_("status").innerHTML = event.target.responseText;
				}
				function errorHandler(event){
					_("status").innerHTML = "Upload Failed";
				}
				function abortHandler(event){
					_("status").innerHTML = "Upload Aborted";
				}
			
		});
		
			$(".hapuskonsumen").click(function(){
				var idCustomer 	= $(this).attr("idCustomer");
				var result = confirm("hapus customer?");
				if (result) {
				
					$.ajax({
						url: "aksi/aksikonsumen.php?act=hapus",
						data: "idCustomer=" + idCustomer,
						success: function(data){
							location.reload();
						}
					});
					return false;
				}
			});
			$(".hapussupplier").click(function(){
				var idSupplier 	= $(this).attr("idSupplier");
				var result = confirm("hapus supplier?");
				if (result) {
				
					$.ajax({
						url: "aksi/aksisupplier.php?act=hapus",
						data: "idSupplier=" + idSupplier,
						success: function(data){
							location.reload();
						}
					});
					return false;
				}
			});
			
			$(".hapuspemesanan").click(function(){
				var idpemesanan 	= $(this).attr("idpemesanan");
				var result = confirm("hapus customer?");
				if (result) {
				
					$.ajax({
						url: "aksi/aksipemesanan.php?act=hapus",
						data: "idpemesanan=" + idpemesanan,
						success: function(data){
							location.reload();
						}
					});
					return false;
				}
			});
			
			$(".konfirmasi").click(function(){
				var idPembayaran 	= $(this).attr("idPembayaran");
				var idPemesanan 	= $(this).attr("idPemesanan");
				var totalPembayaran 	= $(this).attr("totalPembayaran");
				var result = confirm("Konfirmasi Pembayaran?");
				if (result) {
				
					$.ajax({
						url: "aksi/aksipembayaran.php?act=konfirm",
						data: "idPembayaran=" + idPembayaran + "&idPemesanan=" + idPemesanan + "&totalPembayaran=" + totalPembayaran,
						success: function(data){
							location.reload();
						}
					});
					return false;
				}
			});
						
			$("#searchpemesanan").click(function(){
				var date1 	= $("#date1").val();
				var date2 	= $("#date2").val();
				$.ajax({
					url: "modul/laporan/hasilcari.php?act=Pemesanan",
					data: "date1=" + date1 + "&date2=" + date2,
					success: function(data){
						$("#hasilcari").html(data);
					}
				});
				return false;
			});
			$("#searchpembayaran").click(function(){
				var date1 	= $("#date1").val();
				var date2 	= $("#date2").val();
				$.ajax({
					url: "modul/laporan/hasilcari.php?act=Pembayaran",
					data: "date1=" + date1 + "&date2=" + date2,
					success: function(data){
						$("#hasilcari").html(data);
					}
				});
				return false;
			});
			$("#searchpenjualan").click(function(){
				var date1 	= $("#date1").val();
				var date2 	= $("#date2").val();
				$.ajax({
					url: "modul/laporan/hasilcari.php?act=Penjualan",
					data: "date1=" + date1 + "&date2=" + date2,
					success: function(data){
						$("#hasilcari").html(data);
					}
				});
				return false;
			});
			
			
			$("#submitsupplier").click(function(){
				var nameSupplier 	= $("#nameSupplier").val();
				if(nameSupplier==''){
					document.getElementById('nameSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var emailSupplier 	= $("#emailSupplier").val();
				if(emailSupplier==''){
					document.getElementById('emailSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var tlpnSupplier 	= $("#tlpnSupplier").val();
				if(tlpnSupplier==''){
					document.getElementById('tlpnSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var faxSupplier 	= $("#faxSupplier").val();
				if(faxSupplier==''){
					document.getElementById('faxSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var pemilikSupplier 	= $("#pemilikSupplier").val();
				if(pemilikSupplier==''){
					document.getElementById('pemilikSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var alamatSupplier 	= $("#alamatSupplier").val();
				if(alamatSupplier==''){
					document.getElementById('alamatSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				$.ajax({
					url: "aksi/aksisupplier.php?act=insert",
					data: "nameSupplier=" + nameSupplier + "&emailSupplier=" + emailSupplier + "&tlpnSupplier=" + tlpnSupplier + "&faxSupplier=" + faxSupplier + "&alamatSupplier=" + alamatSupplier + "&pemilikSupplier=" + pemilikSupplier,
					success: function(data){
						$("#list_supplier").html(data);
					}
				});
				return false;
			});
			
			$("#submitupdatesupplier").click(function(){
				var idSupplier 	= $("#idSupplier").val();
				var nameSupplier 	= $("#nameSupplier").val();
				if(nameSupplier==''){
					document.getElementById('nameSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var emailSupplier 	= $("#emailSupplier").val();
				if(emailSupplier==''){
					document.getElementById('emailSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var tlpnSupplier 	= $("#tlpnSupplier").val();
				if(tlpnSupplier==''){
					document.getElementById('tlpnSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var faxSupplier 	= $("#faxSupplier").val();
				if(faxSupplier==''){
					document.getElementById('faxSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var pemilikSupplier 	= $("#pemilikSupplier").val();
				if(pemilikSupplier==''){
					document.getElementById('pemilikSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				var alamatSupplier 	= $("#alamatSupplier").val();
				if(alamatSupplier==''){
					document.getElementById('alamatSupplier').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				$.ajax({
					url: "aksi/aksisupplier.php?act=update",
					data: "nameSupplier=" + nameSupplier + "&emailSupplier=" + emailSupplier + "&tlpnSupplier=" + tlpnSupplier + "&faxSupplier=" + faxSupplier + "&alamatSupplier=" + alamatSupplier + "&pemilikSupplier=" + pemilikSupplier + "&idSupplier=" + idSupplier,
					success: function(data){
						$("#list_supplier").html(data);
					}
				});
				return false;
			});
			
			$("#submitstock").click(function(){
				var idBarang 	= $("#idBarang").val();
				var masukStock 	= $("#masukStock").val();
				if(masukStock==''){
					document.getElementById('masukStock').style.border ='2px solid red';
					e.preventDefault(); 
				}
				
				$.ajax({
					url: "aksi/aksistock.php?act=insert",
					data: "idBarang=" + idBarang + "&masukStock=" + masukStock,
					success: function(data){
						$("#list_stock").html(data);
					}
				});
				return false;
			});
		});
    </script>
</body>

</html>
<?php
	}
?>