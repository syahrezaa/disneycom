<?php
	echo"<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tambah Stock
				
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Barang</label>
							<select id='idBarang' class='form-control'>";
								$test = mysql_query("SELECT * FROM Barang");
								while($rk = mysql_fetch_array($test)){
									echo"
									<option id='idBarang' value='$rk[idBarang]'>$rk[nameBarang]</option>";
								}
							echo"	
							</select>
						</div>
					</div>
					
					<div class='col-lg-9'>
						<div class='form-group'>
							<label>Jumlah</label>
							<input type='text' class='form-control' id='masukStock' name='masukStock'>
						</div>
					</div>
					
					<div class='col-lg-12'>
							
							<div id='list_stock'></div>
							<button type='button' id='submitstock' class='btn btn-primary'>Submit</button>
							<a href='?mod=stock'><button type='button' class='btn btn-danger'>Reset</button></a>
						</form>
					</div>

				</div>
			</div>
		</div>
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Stock
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Barang</th>
										<th>Jumlah Masuk</th>
										<th>Jumlah Keluar</th>
										<th>Saldo</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM stock
															INNER JOIN barang
																ON stock.idBarang = barang.idBarang
															ORDER BY stock.idStock DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[nameBarang]</td>
												<td>$rb[masukStock]</td>
												<td>$rb[keluarStock]</td>
												<td>$rb[saldoStock]</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
			</div>
		</div>
	";
?>