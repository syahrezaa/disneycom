<?php
	echo"
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Konfirmasi Pembayaran
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Nama</th>
										<th>Tlpn</th>
										<th>Email</th>
										<th>Kd Pemesanan</th>
										<th>Tgl Pemesanan</th>
										<th>Jumlah Transfer</th>
										<th>Tanggal Transfer</th>
										<th>Bukti Transfer</th>
										<th>Proses</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM pembayaran 
															INNER JOIN pemesanan
																ON pemesanan.idPemesanan = pembayaran.idPemesanan
															INNER JOIN customer
																ON customer.idCustomer = pemesanan.idCustomer
															ORDER BY pembayaran.idPembayaran DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[nameCustomer]</td>
												<td>$rb[tlpnCustomer]</td>
												<td>$rb[emailCustomer]</td>
												<td>
													<a href='javascript:;' style='color:blue' class='' data-toggle='modal' data-target='#myModal1$rb[kdPemesanan]' >$rb[kdPemesanan]</a>
													
													<!-- Modal -->
												  <div class='modal fade' id='myModal1$rb[kdPemesanan]' role='dialog'>
													<div class='modal-dialog'>
													
													  <!-- Modal content-->
													  <div class='modal-content'>
														<div class='modal-header'>
														  <button type='button' class='close' data-dismiss='modal'>&times;</button>
														  <h4 class='modal-title'>Detail Pesanan</h4>
														</div>
														<div class='modal-body'>
														  <table class='table table-bordered'>
															<thead>
																<tr>
																  <th>Product</th>
																  <th>Description</th>
																  <th>Quantity</th>
																  <th>Price</th>
																  <th>Total</th>
																</tr>
															</thead>
															<tbody>";
																$models = mysql_query("SELECT * FROM detailpesanan 
																						INNER JOIN barang
																							ON detailpesanan.idBarang = barang.idBarang
																						WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
																$nos="";
																$totals="";
																while($rbs = mysql_fetch_array($models)){
																	$nos++;
																	$subtotals = $rbs['hargaBarang']* $rbs['qtyDetailpesanan'];
																	$hasis = number_format($subtotals,2,",",".");
																	$hargaBarangs = number_format($rbs['hargaBarang'],2,",",".");
																	echo"
																		<tr>
																			<td><img src='images/$rbs[imgBarang]' width='60' ></td>
																			<td>$rbs[ketBarang] </td>
																			<td>
																				$rbs[qtyDetailpesanan]
																			</td>
																			<td>$hargaBarangs</td>
																			<td>$hasis</td>
																			
																		</tr>";
																	$totals = $totals + $subtotals;
																}
																
																	$hasils = number_format($totals,2,",",".");
															echo"<tr>
																	<td colspan=4 style='text-align:right'>Total</td>
																	<td >Rp. $hasils</td>
																	
																</tr>
															</tbody>
														</table>
														</div>
														<div class='modal-footer'>
														  <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
														</div>
													  </div>
													  
													</div>
												  </div>
												</td>
												<td>$rb[datePemesanan]</td>
												<td>$rb[jumlahPembayaran]</td>
												<td>$rb[datePembayaran]</td>
												<td><img src='images/$rb[ketPembayaran]' width=60></td>
												<td>";
												if($rb['statusPembayaran']==''){
													echo"
													<a href='javascript:;' class='btn btn-success btn-xs konfirmasi' id='konfirmasi' idPembayaran='$rb[idPembayaran]' idPemesanan='$rb[idPemesanan]' totalPembayaran='$rb[jumlahPembayaran]'>Konfirmasi</a>";
												}else{
													echo"Pengiriman";
												}
												echo"
												</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
			</div>
		</div>
		
	";
?>