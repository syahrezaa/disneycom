<?php
	echo"
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Pemesanan
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Tanggal</th>
										<th>Kd Pemesanan</th>
										<th>Jumlah Item</th>
										<th>Total</th>
										<th>Nama Customer</th>
										<th>Tlpn Customer</th>
										<th>Email Customer</th>
										<th>Alamat Customer</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM pemesanan
															INNER JOIN customer
																ON pemesanan.idCustomer = customer.idCustomer
															ORDER BY pemesanan.idpemesanan DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										$models = mysql_query("SELECT * FROM detailpesanan 
																INNER JOIN barang
																	ON detailpesanan.idBarang = barang.idBarang
																WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
										
										$jumlahitem = mysql_num_rows($models);
										$total="";
										while($rbs = mysql_fetch_array($models)){
											
											$subtotal = $rbs['hargaBarang']* $rbs['qtyDetailpesanan'];
											
											$total = $total + $subtotal;
										}
										
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[datePemesanan]</td>
												<td>
													<a href='javascript:;' style='color:blue' class='' data-toggle='modal' data-target='#myModal1$rb[kdPemesanan]' >$rb[kdPemesanan]</a>
													
													<!-- Modal -->
												  <div class='modal fade' id='myModal1$rb[kdPemesanan]' role='dialog'>
													<div class='modal-dialog'>
													
													  <!-- Modal content-->
													  <div class='modal-content'>
														<div class='modal-header'>
														  <button type='button' class='close' data-dismiss='modal'>&times;</button>
														  <h4 class='modal-title'>Detail Pesanan</h4>
														</div>
														<div class='modal-body'>
														  <table class='table table-bordered'>
															<thead>
																<tr>
																  <th>Product</th>
																  <th>Description</th>
																  <th>Quantity</th>
																  <th>Price</th>
																  <th>Total</th>
																</tr>
															</thead>
															<tbody>";
																$models = mysql_query("SELECT * FROM detailpesanan 
																						INNER JOIN barang
																							ON detailpesanan.idBarang = barang.idBarang
																						WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
																$nos="";
																$totals="";
																while($rbs = mysql_fetch_array($models)){
																	$nos++;
																	$subtotals = $rbs['hargaBarang']* $rbs['qtyDetailpesanan'];
																	$hasis = number_format($subtotals,2,",",".");
																	$hargaBarangs = number_format($rbs['hargaBarang'],2,",",".");
																	echo"
																		<tr>
																			<td><img src='images/$rbs[imgBarang]' width='60' ></td>
																			<td>$rbs[ketBarang] </td>
																			<td>
																				$rbs[qtyDetailpesanan]
																			</td>
																			<td>$hargaBarangs</td>
																			<td>$hasis</td>
																			
																		</tr>";
																	$totals = $totals + $subtotals;
																}
																
																	$hasils = number_format($totals,2,",",".");
															echo"<tr>
																	<td colspan=4 style='text-align:right'>Total</td>
																	<td >Rp. $hasils</td>
																	
																</tr>
															</tbody>
														</table>
														</div>
														<div class='modal-footer'>
														  <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
														</div>
													  </div>
													  
													</div>
												  </div>
												</td>
												<td>$jumlahitem</td>
												<td>Rp. $total</td>
												<td>$rb[nameCustomer]</td>
												<td>$rb[notlpnCustomer]</td>
												<td>$rb[emailCustomer]</td>
												<td>$rb[alamatCustomer]</td>
												<td>";
												if($rb['statusPemesanan']=='Proses'){
													echo"
													<a href='javascript:;' class='btn btn-danger btn-xs' data-toggle='modal' data-target='#myModal' >Reject</a>
													<!-- Modal -->
													  <div class='modal fade' id='myModal' role='dialog'>
														<div class='modal-dialog'>
														
														  <!-- Modal content-->
														  <div class='modal-content'>
															<div class='modal-header'>
															  <button type='button' class='close' data-dismiss='modal'>&times;</button>
															  <h4 class='modal-title'>Reject Pesanan</h4>
															</div>
															<div class='modal-body'>
																<textarea id='ketPemesanan' name='ketPemesanan' class='form-control' placeholder='Alasan Reject'></textarea>
															</div>
															<div class='modal-footer'>
															  <button type='button' class='btn btn-danger hapuspesanan' idPemesanan='$rb[idPemesanan]' data-dismiss='modal'>Reject</button>
															</div>
														  </div>
														  
														</div>
													  </div>
													
													";
												}else{
													echo"$rb[statusPemesanan]";
												}
												echo"
												</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
			</div>
		</div>
	";
?>