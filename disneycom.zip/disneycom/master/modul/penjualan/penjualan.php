<?php
	echo"
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Penjualan
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Tanggal</th>
										<th>Kd Pemesanan</th>
										<th>Total Penjualan</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM penjualan
															INNER JOIN pembayaran
																ON penjualan.idPembayaran = pembayaran.idPembayaran
															INNER JOIN pemesanan
																ON pembayaran.idPemesanan = pemesanan.idPemesanan
															ORDER BY penjualan.idPenjualan DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										
										$totalpenjualan = number_format($rb['totalPenjualan'],2,",",".");
										
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[datePenjualan]</td>
												<td>$rb[kdPemesanan]</td>
												<td>Rp. $totalpenjualan</td>
												
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
			</div>
		</div>
	";
?>