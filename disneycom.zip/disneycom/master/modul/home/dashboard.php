<?php
	echo"
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Merek
				
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='form-group'>
							<label>Merek</label>
							<input class='form-control' id='nameMerek' name='nameMerek'>
						</div>
					</div>
					
					<div class='col-lg-12'>
							
							<div id='list_merek'></div>
							<button type='button' id='submitmerek' class='btn btn-primary'>Submit</button>
							<a href='?mod=merek'><button type='button' class='btn btn-danger'>Reset</button></a>
						</form>
					</div>

				</div>
			</div>
		</div>
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Merek
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Merek</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM merek 
															ORDER BY merek.idMerek DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[nameMerek]</td>
												<td>";
													echo"
													<a href='?mod=updatemerek&b=$rb[idMerek]' class='btn btn-warning btn-xs'>Edit</a>
					
													<a href='javascript:;' class='btn btn-danger btn-xs hapusmerek' id='hapusmerek' idMerek='$rb[idMerek]'>Delete</a>	";
													
												echo"
												</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
				<!-- /.row -->
			</div>
			<!-- /.panel-body -->
		</div>
	";
?>