<?php
	echo"
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Supplier
				
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Nama Supplierer</label>
							<input class='form-control' id='nameSupplier' name='nameSupplier'>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Contack Supplier</label>
							<input class='form-control' id='tlpnSupplier' name='tlpnSupplier'>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Email Supplier</label>
							<input class='form-control' id='emailSupplier' name='emailSupplier'>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Fax</label>
							<input class='form-control' id='faxSupplier' name='faxSupplier'>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Alamat Toko</label>
							<textarea id='alamatSupplier' class='form-control' name='alamatSupplier' ></textarea>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Pemilik</label>
							<input class='form-control' id='pemilikSupplier' name='pemilikSupplier'>
						</div>
					</div>
					
					<div class='col-lg-12'>
							
							<div id='list_supplier'></div>
							<button type='button' id='submitsupplier' class='btn btn-primary'>Submit</button>
							<a href='?mod=supplier'><button type='button' class='btn btn-danger'>Reset</button></a>
						</form>
					</div>

				</div>
			</div>
		</div>
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Merek
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Nama Supplier</th>
										<th>Email Supplier</th>
										<th>Fax</th>
										<th>Contack Supplier</th>
										<th>Alamat</th>
										<th>Pemilik</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM supplier 
															ORDER BY supplier.idSupplier DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[nameSupplier]</td>
												<td>$rb[emailSupplier]</td>
												<td>$rb[faxSupplier]</td>
												<td>$rb[tlpnSupplier]</td>
												<td>$rb[alamatSupplier]</td>
												<td>$rb[pemilikSupplier]</td>
												<td>";
													echo"
													<a href='?mod=updatesupplier&b=$rb[idSupplier]' class='btn btn-warning btn-xs'>Edit</a>
					
													<a href='javascript:;' class='btn btn-danger btn-xs hapussupplier' id='hapussupplier' idSupplier='$rb[idSupplier]'>Delete</a>	";
													
												echo"
												</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
				<!-- /.row -->
			</div>
			<!-- /.panel-body -->
		</div>
	";
?>