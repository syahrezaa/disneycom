<?php
$kat=mysql_fetch_array(mysql_query("SELECT * FROM supplier WHERE idSupplier = '$_GET[b]'"));
	echo"
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Supplier
				
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Nama</label>
							<input class='form-control' id='nameSupplier' name='nameSupplier' value='$kat[nameSupplier]'>
							<input class='form-control' id='idSupplier' name='idSupplier' value='$kat[idSupplier]' type='hidden'>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Tlpn</label>
							<input class='form-control' id='tlpnSupplier' name='tlpnSupplier' value='$kat[tlpnSupplier]'>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Email</label>
							<input class='form-control' id='emailSupplier' name='emailSupplier' value='$kat[emailSupplier]'>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Fax</label>
							<input class='form-control' id='faxSupplier' name='faxSupplier' value='$kat[faxSupplier]'>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Alamat</label>
							<textarea id='alamatSupplier' class='form-control' name='alamatSupplier' >$kat[alamatSupplier]</textarea>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Pemilik</label>
							<input class='form-control' value='$kat[pemilikSupplier]' id='pemilikSupplier' name='pemilikSupplier'>
						</div>
					</div>
					
					<div class='col-lg-12'>
							
							<div id='list_supplier'></div>
							<button type='button' id='submitupdatesupplier' class='btn btn-primary'>Submit</button>
							<a href='?mod=supplier'><button type='button' class='btn btn-danger'>Reset</button></a>
						</form>
					</div>

				</div>
			</div>
		</div>
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Merek
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Nama</th>
										<th>Email</th>
										<th>Fax</th>
										<th>Tlpn</th>
										<th>Alamat</th>
										<th>Pemilik</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM supplier 
															ORDER BY supplier.idSupplier DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[nameSupplier]</td>
												<td>$rb[emailSupplier]</td>
												<td>$rb[faxSupplier]</td>
												<td>$rb[tlpnSupplier]</td>
												<td>$rb[alamatSupplier]</td>
												<td>$rb[pemilikSupplier]</td>
												<td>";
													echo"
													<a href='?mod=updatesupplier&b=$rb[idSupplier]' class='btn btn-warning btn-xs'>Edit</a>
					
													<a href='javascript:;' class='btn btn-danger btn-xs hapussupplier' id='hapussupplier' idSupplier='$rb[idSupplier]'>Delete</a>	";
													
												echo"
												</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
				<!-- /.row -->
			</div>
			<!-- /.panel-body -->
		</div>
	";

?>