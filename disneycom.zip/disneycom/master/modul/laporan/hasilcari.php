<?php
include"../../../config/koneksi.php";
if($_GET['act']=='Pemesanan'){
	$date1 = $_GET['date1'];
	$date2 = $_GET['date2'];
	echo"
		<a href='modul/laporan/printpemesanan.php?date1=$_GET[date1]&date2=$_GET[date2]' target=_blank><h3>Print</h3></a>
		<table class='table table-bordered table-hover table-striped'>
		<thead>
			<tr>
				<th>No</th>
				<th>Tanggal</th>
				<th>Kd Pemesanan</th>
				<th>Detail</th>
				<th>Jumlah Item</th>
				<th>Total</th>
				<th>Nama Customer</th>
				<th>Tlpn Customer</th>
				<th>Email Customer</th>
				<th>Alamat Customer</th>
				<th>Proses</th>
			</tr>
		</thead>
		<tbody>";
			$model = mysql_query("SELECT * FROM pemesanan
									INNER JOIN customer
										ON pemesanan.idCustomer = customer.idCustomer
									WHERE pemesanan.datePemesanan BETWEEN '$date1' AND '$date2'
									ORDER BY pemesanan.idpemesanan DESC");
			$no="";
			while($rb = mysql_fetch_array($model)){
				$no++;
				$models = mysql_query("SELECT * FROM detailpesanan 
										INNER JOIN barang
											ON detailpesanan.idBarang = barang.idBarang
										WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
				
				$jumlahitem = mysql_num_rows($models);
				$total="";
				while($rbs = mysql_fetch_array($models)){
					
					$subtotal = $rbs['hargaBarang']* $rbs['qtyDetailpesanan'];
					
					$total = $total + $subtotal;
				}
				
				$hargass2 = number_format($total,2,",",".");
				echo"
					<tr>
						<td>$no</td>
						<td>$rb[datePemesanan]</td>
						<td>$rb[kdPemesanan]</td>
						<td>
							 <table class='table table-bordered'>
							<thead>
								<tr>
								  <th>Product</th>
								  <th>Quantity</th>
								  <th>Price</th>
								  <th>Total</th>
								</tr>
							</thead>
							<tbody>";
								$models = mysql_query("SELECT * FROM detailpesanan 
														INNER JOIN barang
															ON detailpesanan.idBarang = barang.idBarang
														WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
								$nos="";
								$totals="";
								while($rs = mysql_fetch_array($models)){
									$nos++;
									$subtotals = $rs['hargaBarang']* $rs['qtyDetailpesanan'];
									$hasi = number_format($subtotals,2,",",".");
									$hargaBarang = number_format($rs['hargaBarang'],2,",",".");
									echo"
										<tr>
											<td>$rs[nameBarang] </td>
											<td>
												$rs[qtyDetailpesanan]
											</td>
											<td>$hargaBarang</td>
											<td>$hasi</td>
											
										</tr>";
									$totals = $totals + $subtotals;
								}
								
									$hasil = number_format($totals,2,",",".");
							echo"<tr>
									<td colspan=3 style='text-align:right'>Total</td>
									<td >$hasil</td>
									
								</tr>
							</tbody>
						</table>
						
						
						</td>
						<td>$jumlahitem</td>
						<td>$hargass2</td>
						<td>$rb[nameCustomer]</td>
						<td>$rb[notlpnCustomer]</td>
						<td>$rb[emailCustomer]</td>
						<td>$rb[alamatCustomer]</td>
						<td>$rb[statusPemesanan]
						</td>
					</tr>";
			}
		echo"
		</tbody>
	</table>";
	
}elseif($_GET['act']=='Pembayaran'){
	$date1 = $_GET['date1'];
	$date2 = $_GET['date2'];
	echo"
		<a href='modul/laporan/printpembayaran.php?date1=$_GET[date1]&date2=$_GET[date2]' target=_blank><h3>Print</h3></a>
		<table class='table table-bordered table-hover table-striped'>
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Tlpn</th>
				<th>Email</th>
				<th>Kd Pemesanan</th>
				<th>Detail</th>
				<th>Tgl Pemesanan</th>
				<th>Jumlah Transfer</th>
				<th>Tanggal Transfer</th>
				<th>Bukti Transfer</th>
				<th>Proses</th>
			</tr>
		</thead>
		<tbody>";
			$model = mysql_query("SELECT * FROM pembayaran 
									INNER JOIN pemesanan
										ON pemesanan.idPemesanan = pembayaran.idPemesanan
									INNER JOIN customer
										ON customer.idCustomer = pemesanan.idCustomer
									WHERE pembayaran.datePembayaran BETWEEN '$date1' AND '$date2'
									ORDER BY pembayaran.idPembayaran DESC");
			$no="";
			$total=0;
			while($rb = mysql_fetch_array($model)){
				$no++;
				
				$hargass3 = number_format($rb['jumlahPembayaran'],2,",",".");
				echo"
					<tr>
						<td>$no</td>
						<td>$rb[nameCustomer]</td>
						<td>$rb[notlpnCustomer]</td>
						<td>$rb[emailCustomer]</td>
						<td>$rb[kdPemesanan]</td>
						<td>
							 <table class='table table-bordered'>
							<thead>
								<tr>
								  <th>Product</th>
								  <th>Quantity</th>
								  <th>Price</th>
								  <th>Total</th>
								</tr>
							</thead>
							<tbody>";
								$models = mysql_query("SELECT * FROM detailpesanan 
														INNER JOIN barang
															ON detailpesanan.idBarang = barang.idBarang
														WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
								$nos="";
								$totals="";
								while($rs = mysql_fetch_array($models)){
									$nos++;
									$subtotals = $rs['hargaBarang']* $rs['qtyDetailpesanan'];
									$hasi = number_format($subtotals,2,",",".");
									$hargaBarang = number_format($rs['hargaBarang'],2,",",".");
									echo"
										<tr>
											<td>$rs[nameBarang] </td>
											<td>
												$rs[qtyDetailpesanan]
											</td>
											<td>$hargaBarang</td>
											<td>$hasi</td>
											
										</tr>";
									$totals = $totals + $subtotals;
								}
								
									$hasil = number_format($totals,2,",",".");
							echo"<tr>
									<td colspan=3 style='text-align:right'>Total</td>
									<td >$hasil</td>
									
								</tr>
							</tbody>
						</table>
						
						
						</td>
						<td>$rb[datePemesanan]</td>
						<td>$hargass3</td>
						<td>$rb[datePembayaran]</td>
						<td><img src='images/$rb[ketPembayaran]' width=60></td>
						<td>$rb[statusPembayaran]
						</td>
					</tr>";
					
					$total = $total + $rb['jumlahPembayaran'];
			}
				$hargass4 = number_format($total,2,",",".");
		echo"
		<tr>
			<td colspan='6'>Total</td>
			<td colspan='4'>$hargass4</td>
		</tr>
		</tbody>
	</table>";
}elseif($_GET['act']=='Penjualan'){
	$date1 = $_GET['date1'];
	$date2 = $_GET['date2'];
	echo"
		<a href='modul/laporan/printpenjualan.php?date1=$_GET[date1]&date2=$_GET[date2]' target=_blank><h3>Print</h3></a>
		<table class='table table-bordered table-hover table-striped'>
		<thead>
			<tr>
				<th>No</th>
				<th>Tanggal</th>
				<th>Kd Pemesanan</th>
				<th>Detail</th>
				<th>Total Penjualan</th>
			</tr>
		</thead>
		<tbody>";
			$model = mysql_query("SELECT * FROM penjualan
									INNER JOIN pembayaran
										ON penjualan.idPembayaran = pembayaran.idPembayaran
									INNER JOIN pemesanan
										ON pembayaran.idPemesanan = pemesanan.idPemesanan
									WHERE penjualan.datePenjualan BETWEEN '$date1' AND '$date2'
									ORDER BY penjualan.idPenjualan DESC");
			$no="";
			$total=0;
			while($rb = mysql_fetch_array($model)){
				$no++;
				
				$hargass = number_format($rb['totalPenjualan'],2,",",".");
				
				echo"
					<tr>
						<td>$no</td>
						<td>$rb[datePenjualan]</td>
						<td>$rb[kdPemesanan]</td>
						<td>
							 <table class='table table-bordered'>
							<thead>
								<tr>
								  <th>Product</th>
								  <th>Quantity</th>
								  <th>Price</th>
								  <th>Total</th>
								</tr>
							</thead>
							<tbody>";
								$models = mysql_query("SELECT * FROM detailpesanan 
														INNER JOIN barang
															ON detailpesanan.idBarang = barang.idBarang
														WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
								$nos="";
								$totals="";
								while($rs = mysql_fetch_array($models)){
									$nos++;
									$subtotals = $rs['hargaBarang']* $rs['qtyDetailpesanan'];
									$hasi = number_format($subtotals,2,",",".");
									$hargaBarang = number_format($rs['hargaBarang'],2,",",".");
									echo"
										<tr>
											<td>$rs[nameBarang] </td>
											<td>
												$rs[qtyDetailpesanan]
											</td>
											<td>$hargaBarang</td>
											<td>$hasi</td>
											
										</tr>";
									$totals = $totals + $subtotals;
								}
								
									$hasil = number_format($totals,2,",",".");
							echo"<tr>
									<td colspan=3 style='text-align:right'>Total</td>
									<td >$hasil</td>
									
								</tr>
							</tbody>
						</table>
						
						
						</td>
						<td>$hargass</td>
						
					</tr>";
					$total = $total + $rb['totalPenjualan'];
			}
					$hasils = number_format($total,2,",",".");
		echo"
		<tr>
			<td colspan='4'>Total</td>
			<td>$hasils</td>
		</tr>
		</tbody>
	</table>";
}

?>