<link href="../../../css/bootstrap.min.css" rel="stylesheet">
<?php
include"../../../config/koneksi.php";
	$date1 = $_GET['date1'];
	$date2 = $_GET['date2'];
	echo"
		<h3 align='center'>Disney Com Pekanbaru</h3>
		<p  align='center'>Laporan pemesanan dari tanggal $date1 sampai $date2</p>
		<table class='table table-bordered table-hover table-striped'>
		<thead>
			<tr>
				<th>No</th>
				<th>Tanggal</th>
				<th>Kd Pemesanan</th>
				<th>Detail</th>
				<th>Total Penjualan</th>
			</tr>
		</thead>
		<tbody>";
			$model = mysql_query("SELECT * FROM penjualan
									INNER JOIN pembayaran
										ON penjualan.idPembayaran = pembayaran.idPembayaran
									INNER JOIN pemesanan
										ON pembayaran.idPemesanan = pemesanan.idPemesanan
									WHERE penjualan.datePenjualan BETWEEN '$date1' AND '$date2'
									ORDER BY penjualan.idPenjualan DESC");
			$no="";
			$total=0;
			while($rb = mysql_fetch_array($model)){
				$no++;
				
				$hargass = number_format($rb['totalPenjualan'],2,",",".");
				
				echo"
					<tr>
						<td>$no</td>
						<td>$rb[datePenjualan]</td>
						<td>$rb[kdPemesanan]</td>
						<td>
							 <table class='table table-bordered'>
							<thead>
								<tr>
								  <th>Product</th>
								  <th>Quantity</th>
								  <th>Price</th>
								  <th>Total</th>
								</tr>
							</thead>
							<tbody>";
								$models = mysql_query("SELECT * FROM detailpesanan 
														INNER JOIN barang
															ON detailpesanan.idBarang = barang.idBarang
														WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
								$nos="";
								$totals="";
								while($rs = mysql_fetch_array($models)){
									$nos++;
									$subtotals = $rs['hargaBarang']* $rs['qtyDetailpesanan'];
									$hasi = number_format($subtotals,2,",",".");
									$hargaBarang = number_format($rs['hargaBarang'],2,",",".");
									echo"
										<tr>
											<td>$rs[nameBarang] </td>
											<td>
												$rs[qtyDetailpesanan]
											</td>
											<td>$hargaBarang</td>
											<td>$hasi</td>
											
										</tr>";
									$totals = $totals + $subtotals;
								}
								
									$hasil = number_format($totals,2,",",".");
							echo"<tr>
									<td colspan=3 style='text-align:right'>Total</td>
									<td >$hasil</td>
									
								</tr>
							</tbody>
						</table>
						
						
						</td>
						<td>$hargass</td>
						
					</tr>";
					$total = $total + $rb['totalPenjualan'];
			}
					$hasils = number_format($total,2,",",".");
		echo"
		<tr>
			<td colspan='4'>Total</td>
			<td>$hasils</td>
		</tr>
		</tbody>
	</table>";
?>