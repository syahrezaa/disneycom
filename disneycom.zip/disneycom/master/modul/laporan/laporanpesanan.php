<?php
	echo"
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Laporan Pemesanan
				
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div>
							Cari Tanggal
							<input type='text' class='datepicker ' id='date1' >
							Sampai
							<input type='text' class='datepicker ' id='date2' >
							<button type='button' class='btn btn-sm btn-default' id='searchpemesanan'>Cari </button>							
						<div>
						
						<br/>
						
						<div class='table-responsive' id='hasilcari'>
							
						</div>

					</div>

				</div>
			</div>
		</div>
	";
?>