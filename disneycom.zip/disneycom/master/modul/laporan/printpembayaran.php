<link href="../../../css/bootstrap.min.css" rel="stylesheet">
<?php
include"../../../config/koneksi.php";
	$date1 = $_GET['date1'];
	$date2 = $_GET['date2'];
	echo"
		<h3 align='center'>Disney Com Pekanbaru</h3>
		<p  align='center'>Laporan pemesanan dari tanggal $date1 sampai $date2</p>
		<table class='table table-bordered table-hover table-striped'>
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Tlpn</th>
				<th>Email</th>
				<th>Kd Pemesanan</th>
				<th>Detail</th>
				<th>Tgl Pemesanan</th>
				<th>Jumlah Transfer</th>
				<th>Tanggal Transfer</th>
				<th>Bukti Transfer</th>
				<th>Proses</th>
			</tr>
		</thead>
		<tbody>";
			$model = mysql_query("SELECT * FROM pembayaran 
									INNER JOIN pemesanan
										ON pemesanan.idPemesanan = pembayaran.idPemesanan
									INNER JOIN customer
										ON customer.idCustomer = pemesanan.idCustomer
									WHERE pembayaran.datePembayaran BETWEEN '$date1' AND '$date2'
									ORDER BY pembayaran.idPembayaran DESC");
			$no="";
			$total=0;
			while($rb = mysql_fetch_array($model)){
				$no++;
				
				$hargass3 = number_format($rb['jumlahPembayaran'],2,",",".");
				echo"
					<tr>
						<td>$no</td>
						<td>$rb[nameCustomer]</td>
						<td>$rb[notlpnCustomer]</td>
						<td>$rb[emailCustomer]</td>
						<td>$rb[kdPemesanan]</td>
						<td>
							 <table class='table table-bordered'>
							<thead>
								<tr>
								  <th>Product</th>
								  <th>Quantity</th>
								  <th>Price</th>
								  <th>Total</th>
								</tr>
							</thead>
							<tbody>";
								$models = mysql_query("SELECT * FROM detailpesanan 
														INNER JOIN barang
															ON detailpesanan.idBarang = barang.idBarang
														WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
								$nos="";
								$totals="";
								while($rs = mysql_fetch_array($models)){
									$nos++;
									$subtotals = $rs['hargaBarang']* $rs['qtyDetailpesanan'];
									$hasi = number_format($subtotals,2,",",".");
									$hargaBarang = number_format($rs['hargaBarang'],2,",",".");
									echo"
										<tr>
											<td>$rs[nameBarang] </td>
											<td>
												$rs[qtyDetailpesanan]
											</td>
											<td>$hargaBarang</td>
											<td>$hasi</td>
											
										</tr>";
									$totals = $totals + $subtotals;
								}
								
									$hasil = number_format($totals,2,",",".");
							echo"<tr>
									<td colspan=3 style='text-align:right'>Total</td>
									<td >$hasil</td>
									
								</tr>
							</tbody>
						</table>
						
						
						</td>
						<td>$rb[datePemesanan]</td>
						<td>$hargass3</td>
						<td>$rb[datePembayaran]</td>
						<td><img src='../../images/$rb[ketPembayaran]' width=60></td>
						<td>$rb[statusPembayaran]
						</td>
					</tr>";
					
					$total = $total + $rb['jumlahPembayaran'];
			}
				$hargass4 = number_format($total,2,",",".");
		echo"
		<tr>
			<td colspan='6'>Total</td>
			<td colspan='4'>$hargass4</td>
		</tr>
		</tbody>
	</table>";
?>