<?php
	echo"
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Customer
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Nama</th>
										<th>Alamat</th>
										<th>Tlpn</th>
										<th>Email</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM customer
															ORDER BY customer.idCustomer DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[nameCustomer]</td>
												<td>$rb[alamatCustomer]</td>
												<td>$rb[notlpnCustomer]</td>
												<td>$rb[emailCustomer]</td>
												<td>";
													echo"
													<a href='javascript:;' class='btn btn-danger btn-xs hapuskonsumen' id='hapuskonsumen' idCustomer='$rb[idCustomer]'>Delete</a>	";
													
												echo"
												</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
			</div>
		</div>
	";
?>