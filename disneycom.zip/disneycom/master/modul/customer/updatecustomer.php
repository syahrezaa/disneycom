<?php
$kat=mysql_fetch_array(mysql_query("SELECT * FROM catalog WHERE idcatalog = '$_GET[b]'"));
	echo"
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Catalog
				
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Kategori</label>
							<select id='idkategori' class='form-control'>";
								$test = mysql_query("SELECT * FROM kategori");
								while($rk = mysql_fetch_array($test)){
									if($rk['idkategori']==$kat['idkategori']){
										echo"
										<option id='idkategori' value='$rk[idkategori]' selected>$rk[kategori]</option>";
									}else{
										echo"
										option id='idkategori' value='$rk[idkategori]'>$rk[kategori]</option>";
									}
								}
							echo"	
							</select>
						</div>
					</div>
					<div class='col-lg-9'>
						<div class='form-group'>
							<label>Judul</label>
							<input type='hidden' class='form-control' id='idcatalog' name='idcatalog' value='$kat[idcatalog]'>
							<input type='text' class='form-control' id='namacatalog' name='namacatalog' value='$kat[namacatalog]'>
						</div>
					</div>
					
					<div class='col-lg-12'>
						<div class='form-group'>
							<textarea class='form-control' rows='3' id='ketcatalog' name='ketcatalog' placeholder='ulasan singkat catalog'>$kat[ketcatalog]</textarea>
						</div>
					</div>
					
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Image</label>
							<input class='form-control' id='files' name='files' type='file'>
						</div>
						<div id='progressupload' style='display:none;'>
							<progress id='progressBar1' value='0' max='100' style='width:100px;margin-left:5px;'></progress>
							<div id='status'></div>
							<p id='loaded_n_total'></p>
						</div>
						<div>
							<img src='images/$kat[imgcatalog]' width=200px;>
						</div>
					</div>	
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Harga</label>
							<input type='text' class='form-control' id='hargacatalog' name='hargacatalog' value='$kat[hargacatalog]'>
						</div>
					</div>
					
					<div class='col-lg-12'>
							
							<div id='list_catalog'></div>
							<button type='button' id='submitupdatecatalog' class='btn btn-primary'>Submit</button>
							<a href='?mod=catalog'><button type='button' class='btn btn-danger'>Reset</button></a>
						</form>
					</div>

				</div>
			</div>
		</div>
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Catalog
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Nama</th>
										<th>Gambar</th>
										<th>Harga</th>
										<th>Kategori</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM catalog
															INNER JOIN kategori
																ON catalog.idkategori = kategori.idkategori
															ORDER BY catalog.idcatalog DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[namacatalog]</td>
												<td><img src='images/$rb[imgcatalog]' width=100px></td>
												<td>$rb[hargacatalog]</td>
												<td>$rb[kategori]</td>
												<td>";
													echo"
													<a href='?mod=updatecatalog&b=$rb[idcatalog]' class='btn btn-warning btn-xs'>Edit</a>
					
													<a href='javascript:;' class='btn btn-danger btn-xs hapuscatalog' id='hapuscatalog' idcatalog='$rb[idcatalog]'>Delete</a>	";
													
												echo"
												</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
			</div>
		</div>
	";
?>