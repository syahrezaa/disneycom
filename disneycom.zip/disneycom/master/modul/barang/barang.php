<?php
	echo"
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Barang
				
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Merek</label>
							<select id='idMerek' class='form-control'>";
								$test = mysql_query("SELECT * FROM merek");
								while($rk = mysql_fetch_array($test)){
									echo"
									<option id='idMerek' value='$rk[idMerek]'>$rk[nameMerek]</option>";
								}
							echo"	
							</select>
						</div>
					</div>
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Supplier</label>
							<select id='idSupplier' class='form-control'>";
								$test = mysql_query("SELECT * FROM supplier");
								while($rk = mysql_fetch_array($test)){
									echo"
									<option id='idSupplier' value='$rk[idSupplier]'>$rk[nameSupplier]</option>";
								}
							echo"	
							</select>
						</div>
					</div>
					<div class='col-lg-9'>
						<div class='form-group'>
							<label>Nama</label>
							<input type='text' class='form-control' id='nameBarang' name='nameBarang'>
						</div>
					</div>
					
					<div class='col-lg-12'>
						<div class='form-group'>
							<textarea class='form-control' rows='3' id='ketBarang' name='ketBarang' placeholder='ulasan singkat barang'></textarea>
						</div>
					</div>
					
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Image</label>
							<input class='form-control' id='files' name='files' type='file'>
						</div>
						<div id='progressupload' style='display:none;'>
							<progress id='progressBar1' value='0' max='100' style='width:100px;margin-left:5px;'></progress>
							<div id='status'></div>
							<p id='loaded_n_total'></p>
						</div>
					</div>	
					<div class='col-lg-3'>
						<div class='form-group'>
							<label>Harga</label>
							<input type='text' class='form-control' id='hargaBarang' name='hargaBarang' value='$kat[hargaBarang]'>
						</div>
					</div>
					
					<div class='col-lg-12'>
							
							<div id='list_barang'></div>
							<button type='button' id='submitbarang' class='btn btn-primary'>Submit</button>
							<a href='?mod=barang'><button type='button' class='btn btn-danger'>Reset</button></a>
						</form>
					</div>

				</div>
			</div>
		</div>
		
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Tabel Barang
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-12'>
						<div class='table-responsive'>
							<table class='table table-bordered table-hover table-striped'>
								<thead>
									<tr>
										<th>No</th>
										<th>Nama</th>
										<th>Gambar</th>
										<th>Harga</th>
										<th>Merek</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>";
									$model = mysql_query("SELECT * FROM barang
															INNER JOIN merek
																ON barang.idMerek = merek.idMerek
															ORDER BY barang.idBarang DESC");
									$no="";
									while($rb = mysql_fetch_array($model)){
										$no++;
										
										$tampilharga = number_format($rb['hargaBarang'],2,",",".");
										
										echo"
											<tr>
												<td>$no</td>
												<td>$rb[nameBarang]</td>
												<td><img src='images/$rb[imgBarang]' width=100px></td>
												<td>Rp. $tampilharga</td>
												<td>$rb[nameMerek]</td>
												<td>";
													echo"
													<a href='?mod=updatebarang&b=$rb[idBarang]' class='btn btn-warning btn-xs'>Edit</a>
					
													<a href='javascript:;' class='btn btn-danger btn-xs hapuscatalog' id='hapuscatalog' idBarang='$rb[idBarang]'>Delete</a>	";
													
												echo"
												</td>
											</tr>";
									}
								echo"
								</tbody>
							</table>
						</div>

					</div>

				</div>
			</div>
		</div>
	";
?>