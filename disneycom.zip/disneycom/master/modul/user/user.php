<?php
echo"
		<div class='panel panel-default'>
			<div class='panel-heading'>
				<i class='fa fa-bar-chart-o fa-fw'></i> Form User
				<div class='pull-right'>
					<div class='btn-group'>
						<button type='button' class='btn btn-default btn-xs dropdown-toggle' data-toggle='dropdown' id='minimaze'>
							<i class='fa fa-minus '></i>
						</button>
					</div>
				</div>
			</div>

			<div class='panel-body'>
				<div class='row'>
					<div class='col-lg-6'>
						<div class='form-group'>
							<label>Nama</label>
							<input class='form-control' id='nameUser' name='nameUser'>
						</div>
					</div>
					<div class='col-lg-6'>
						<div class='form-group'>
							<label>Username</label>
							<input class='form-control' id='usernameUser' name='usernameUser'>
						</div>
					</div>
					<div class='col-lg-6'>
						<div class='form-group'>
							<label>Password</label>
							<input class='form-control' id='passwordUser' name='passwordUser' type='password'>
						</div>
					</div>
					<div class='col-lg-6'>
						<div class='form-group'>
							<label>Email</label>
							<input class='form-control' id='emailUser' name='emailUser'>
						</div>
					</div>
					
					<div class='col-lg-12'>
							
							<div id='list_user'></div>
							<button type='button' id='submituser' class='btn btn-primary'>Submit</button>
							<a href='?mod=user'><button type='button' class='btn btn-danger'>Reset</button></a>
						</form>
					</div>

				</div>
			</div>
		</div>	
		
	

	<div class='panel panel-default'>
		<div class='panel-heading'>
			<i class='fa fa-bar-chart-o fa-fw'></i> Tabel User
		</div>

		<div class='panel-body'>
			<div class='row'>
				<div class='col-lg-12'>
					<div class='table-responsive'>
						<table class='table table-bordered table-hover table-striped'>
							<thead>
								<tr>
									<th>No</th>
									<th>Nama</th>
									<th>Username</th>
									<th>Email</th>
									<th></th>
								</tr>
							</thead>
							<tbody>";
								$user = mysql_query("SELECT * FROM user 
														ORDER BY user.idUser DESC");
								$no="";
								while($rb = mysql_fetch_array($user)){
									$no++;
									echo"
										<tr>
											<td>$no</td>
											<td>$rb[nameUser]</td>
											<td>$rb[usernameUser]</td>
											<td>$rb[emailUser]</td>
											<td>";
												echo"
												<a href='?mod=updateuser&b=$rb[idUser]' class='btn btn-warning btn-xs'>edit</a>
				
												<a href='javascript:;' class='btn btn-danger btn-xs hapususer' id='hapususer' idUser='$rb[idUser]'>hapus</a>	";
												
											echo"
											</td>
										</tr>";
								}
							echo"
							</tbody>
						</table>
					</div>

				</div>

			</div>
		</div>
	</div>

	</div>";
?>
