<?php
$merek = mysql_fetch_array(mysql_query("SELECT * FROM merek WHERE merek.idMerek = '$_GET[id]'"));
echo"
<ul class='breadcrumb'>
	<li><a href='index.php'>Home</a> <span class='divider'>/</span></li>
	<li class='active'>$merek[nameMerek]</li>
</ul>
<ul class='thumbnails'>";

$barang = mysql_query("SELECT * FROM barang WHERE barang.idMerek = '$_GET[id]'");
while($br = mysql_fetch_array($barang)){
	echo"
	<li class='span3'>
	  <div class='thumbnail'>
		<a href='detail.php?id=$br[idBarang]'>
			<img src='master/images/$br[imgBarang]' alt='' />
		</a>
		<div class='caption'>
		  <h5>$br[nameBarang]<br/>
				Rp. $br[hargaBarang]
		  </h5>
		  <h4><a class='btn' href='detail.php?id=$br[idBarang]'>Lihat</a></h4>
		</div>
	  </div>
	</li>";
}
echo"</ul>";
?>
	