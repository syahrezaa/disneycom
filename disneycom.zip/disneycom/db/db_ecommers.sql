-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 09 Jul 2017 pada 17.47
-- Versi Server: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ecommers`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `idBarang` int(10) NOT NULL,
  `nameBarang` varchar(40) NOT NULL,
  `idMerek` int(10) NOT NULL,
  `ketBarang` text NOT NULL,
  `imgBarang` text NOT NULL,
  `hargaBarang` double(12,2) NOT NULL,
  `idSupplier` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`idBarang`, `nameBarang`, `idMerek`, `ketBarang`, `imgBarang`, `hargaBarang`, `idSupplier`) VALUES
(17, 'Toshiba Sattelite Radius P25W-C2300-4K -', 13, 'Intel Core i7-6500U - 2.5 Ghz up to 3.10 GHzRAM 8GBHDD 256GB SSDScreen 12.5" 4K Ultra HD  Touch (16:9 aspect ratio,3840x2160,Supports 2160p content)Windows 10', '06072017122348toshiba sattelite.jpg', 12000000.00, 2),
(18, 'Axio Windroid 9G Plus - 8.9" IPS LCD', 16, 'Intel ATOM Processor Z37358.9" IPS LCD (1280x800)2.0MPx Rear   0.3 MPx Front2 GB RAM   32 GB Storage4.800 mAh Battery ', '06072017122732axio.jpg', 2775000.00, 3),
(19, 'ASUS X454YA-BX801D - RAM 4GB - QuadCore ', 14, 'AMD QuadCore A8 7410-2.2 Ghz Turbo 2.5GhzRAM 4GBHDD 500GBScreen 14"Dos', '06072017122948asus x454.jpg', 2000000.00, 1),
(20, 'ASUS ROG GL552VX-DM044T - RAM 8GB - Inte', 14, 'Intel Core i7-6700HQ - 2.60 up to 3.50 GhzRAM 8GB DDR4HDD 1000GB / 1TBVGA nVidia GTX950M-2GBScreen 15.6"FHDWindows 10', '06072017123239asus rog.jpg', 12000000.00, 1),
(21, 'Asus E202SA-FD011D - Intel N3050 - 2GB -', 14, '11.6" HD LED Back-Lit (1366x768)Intel CeleronÂ® N3050 Processor (2M Cache, up to 2.16 GHz)2 GB DDR3 , 1600 MHz RAM 500GB ( 5400rpm )Intel HD GraphicsDOS', '06072017123404asus e220.jpg', 200000.00, 1),
(22, 'Asus E202SA-FD114D - RAM 2GB - Intel Cel', 14, 'Size: 11.6 inch, OS : DOSRAM : 2 GB / HDD :500 GBIntel Celeron N3060 ( 1.6 - 2.48 GHz, 2 MB cache, 2 cores)Graphics Card : Intel HD Graphics 400 (Integrated)', '06072017123705asus e202.jpg', 6000000.00, 1),
(23, 'Asus X441UV-WX095D I3-6006-VGA GT920 2GB', 14, 'Intel Core i3-6006UNVIDIA GeForce GT920M 2GB DDR3Ram 4GB DDR3500 GB HDD14.0Bluetooth, wifi, webcam, dos, usb 3.0, HDMI, DVD-RWGaransi resmi asus 2 tahun.', '06072017123757asus x441.jpg', 500000.00, 1),
(24, 'Lenovo IdeaPad B41-35 - RAM 6GB - Quad C', 13, 'AMD A8-7410 Quad Core 2.2-2.5GHzRAM 6GB DDR3, 500GB HDD14" HD LED AG, DVD-RWAMD Radeon R5 Integrated Graphic Up To 2GBFingerPrint, Bluetooth, WiFi DOS', '06072017124033lenovo ideapad.jpg', 400000.00, 1),
(26, 'Lenovo - S500 - Intel Core i5-4460S - 8G', 17, 'Intel Core i5-4460S 2.9GHz1TB HDDRAM 8GB DDR3Thinkvision 19''dos', '06072017124400lenovo s500.jpg', 3500000.00, 4),
(27, 'Dell Inspiron 3250 - i5-6400 Win10', 18, '-Intel Core i5-6400U 3.30GHz-8GB DDR31TB HDDDVD-RWnVidiaÂ® -GeForceÂ® 705 2GB-19.5 Inch Monitor-Windows 10 Home1 Years Onsite Warranty', '06072017124517pc dell inpiron.jpg', 5900000.00, 5),
(28, 'Acer Aspire Ram 4 GB Layar 14.0 Inch', 15, 'Desain Premium dan ModernTeknologi Wireless 3x Lebih CepatVGA Terbaru DDR5Baterai Paling Juara di KelasnyaUpgradable RAM dan Storage', '09072017143442acer.jpg', 2900000.00, 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `idCustomer` int(10) NOT NULL,
  `nameCustomer` varchar(40) NOT NULL,
  `alamatCustomer` text NOT NULL,
  `notlpnCustomer` varchar(18) NOT NULL,
  `emailCustomer` varchar(30) NOT NULL,
  `joinCustomer` datetime NOT NULL,
  `passwordCustomer` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`idCustomer`, `nameCustomer`, `alamatCustomer`, `notlpnCustomer`, `emailCustomer`, `joinCustomer`, `passwordCustomer`) VALUES
(10, 'asd', 'asdsad', '23423434', 'ee@gmail.com', '0000-00-00 00:00:00', 'c4ca4238a0b923820dcc509a6f75849b'),
(11, 'vikry', 'jln.sudirman', '08123', 'vikry@gmail.com', '0000-00-00 00:00:00', 'c4ca4238a0b923820dcc509a6f75849b'),
(12, 'syahreza', 'kasdm', '8081293', 'er@gmail.com', '0000-00-00 00:00:00', 'c4ca4238a0b923820dcc509a6f75849b'),
(13, 'syahreza', 'asd', '0817237', 'err@gmail.com', '0000-00-00 00:00:00', 'c4ca4238a0b923820dcc509a6f75849b');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailpesanan`
--

CREATE TABLE `detailpesanan` (
  `idDetailpesanan` int(10) NOT NULL,
  `idPemesanan` int(20) NOT NULL,
  `idBarang` int(10) NOT NULL,
  `qtyDetailpesanan` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detailpesanan`
--

INSERT INTO `detailpesanan` (`idDetailpesanan`, `idPemesanan`, `idBarang`, `qtyDetailpesanan`) VALUES
(1, 1, 2, 1),
(2, 1, 4, 1),
(4, 5, 3, 1),
(5, 5, 1, 1),
(7, 6, 1, 1),
(11, 1496559600, 3, 1),
(12, 1496559601, 1, 1),
(13, 1496559602, 3, 2),
(14, 0, 0, 0),
(15, 0, 0, 0),
(16, 1496559603, 2, 1),
(17, 1496559604, 4, 7),
(18, 1496559605, 3, 0),
(20, 1496559606, 1, 1),
(21, 1496559606, 1, 0),
(22, 1496559606, 3, 0),
(23, 1496559606, 1, 2),
(24, 1496559607, 2, 2),
(25, 1496559608, 1, 1),
(26, 1496559608, 3, 2),
(27, 1496559609, 1, 1),
(28, 1496559610, 1, 1),
(29, 1496559610, 1, 2),
(30, 1496559611, 1, 2),
(33, 1496559614, 1, 2),
(34, 1496559615, 3, 2),
(35, 1496559616, 3, 2),
(36, 1496559616, 1, 2),
(37, 1496559616, 2, 1),
(38, 1496559616, 2, 1),
(39, 1496559616, 2, 3),
(40, 1496559616, 2, 3),
(41, 1496559617, 0, 1),
(43, 1496559617, 2, 1),
(44, 1496559618, 0, 0),
(45, 1496559618, 1, 1),
(46, 1496559618, 1, 1),
(47, 1496559619, 1, 2),
(48, 1496559620, 1, 1),
(49, 1496559620, 2, 1),
(50, 1496559621, 2, 1),
(51, 1496559622, 8, 1),
(52, 1496559622, 9, 1),
(53, 1496559623, 14, 1),
(54, 1496559624, 14, 1),
(55, 1496559625, 16, 1),
(56, 1496559626, 27, 1),
(57, 1496559627, 18, 3),
(58, 1496559628, 19, 2),
(59, 1496559629, 18, 1),
(61, 1496559629, 20, 2),
(62, 1496559630, 19, 1),
(63, 1496559631, 18, 1),
(64, 1496559632, 18, 2),
(65, 1496559633, 24, 1),
(66, 1496559634, 18, 1),
(67, 1496559635, 18, 1),
(69, 1496559636, 19, 1),
(70, 1496559637, 24, 1),
(71, 1496559638, 20, 1),
(72, 1496559639, 18, 1),
(73, 1496559640, 24, 1),
(74, 1496559641, 20, 1),
(75, 1496559642, 24, 1),
(76, 1496559643, 17, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `merek`
--

CREATE TABLE `merek` (
  `idMerek` int(10) NOT NULL,
  `nameMerek` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `merek`
--

INSERT INTO `merek` (`idMerek`, `nameMerek`) VALUES
(13, 'Toshiba'),
(14, 'Asus'),
(15, 'Acer'),
(16, 'Axio'),
(17, 'Lenovo'),
(18, 'Dell');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `idPembayaran` int(10) NOT NULL,
  `idPemesanan` int(10) NOT NULL,
  `jumlahPembayaran` double(15,2) NOT NULL,
  `datePembayaran` date NOT NULL,
  `statusPembayaran` varchar(30) NOT NULL,
  `ketPembayaran` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`idPembayaran`, `idPemesanan`, `jumlahPembayaran`, `datePembayaran`, `statusPembayaran`, `ketPembayaran`) VALUES
(21, 1496559626, 5900000.00, '2017-07-06', '', ''),
(22, 1496559627, 8325000.00, '2017-07-06', 'Paid', ''),
(23, 1496559628, 4000000.00, '2017-07-06', '', ''),
(24, 1496559629, 26775000.00, '2017-07-06', 'Paid', ''),
(25, 1496559631, 2775000.00, '2017-07-06', '', ''),
(26, 1496559632, 5550000.00, '2017-07-06', '', ''),
(27, 1496559633, 400000.00, '2017-07-06', 'Paid', ''),
(28, 1496559634, 2775000.00, '2017-07-06', 'Paid', '0607201714425918194050_1927362774213841_2894836080437780892_n.jpg'),
(29, 1496559635, 2775000.00, '2017-07-07', 'Paid', '07072017172546logo3.png'),
(30, 1496559636, 2000000.00, '2017-07-07', '', '07072017172706facebook.png'),
(31, 1496559637, 400000.00, '2017-07-07', 'Paid', '07072017173103dribbble.png'),
(32, 1496559639, 2775000.00, '2017-07-07', '', '07072017174355arrow-next.png'),
(33, 1496559640, 400000.00, '2017-07-07', '', '07072017180945logo3.png'),
(34, 1496559642, 400000.00, '2017-07-09', 'Paid', '09072017144221bca1.jpg'),
(35, 1496559643, 12000000.00, '2017-07-09', 'Paid', '09072017145141bca2.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan`
--

CREATE TABLE `pemesanan` (
  `idPemesanan` int(20) NOT NULL,
  `datePemesanan` date NOT NULL,
  `idCustomer` int(10) NOT NULL,
  `ketPemesanan` text NOT NULL,
  `totalPemesanan` double(15,2) NOT NULL,
  `statusPemesanan` varchar(20) NOT NULL DEFAULT 'Open',
  `kdPemesanan` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pemesanan`
--

INSERT INTO `pemesanan` (`idPemesanan`, `datePemesanan`, `idCustomer`, `ketPemesanan`, `totalPemesanan`, `statusPemesanan`, `kdPemesanan`) VALUES
(1496559626, '2017-07-06', 10, '', 5900000.00, 'Bayar', 1499320261),
(1496559627, '2017-07-06', 10, '', 8325000.00, 'Paid', 1499320533),
(1496559628, '2017-07-06', 10, '', 4000000.00, 'Bayar', 1499320663),
(1496559629, '2017-07-06', 11, '', 26775000.00, 'Paid', 1499325368),
(1496559630, '2017-07-06', 10, 'asd', 2000000.00, 'Reject', 1499325928),
(1496559631, '2017-07-06', 10, '', 2775000.00, 'Bayar', 1499326422),
(1496559632, '2017-07-06', 10, '', 5550000.00, 'Bayar', 1499326501),
(1496559633, '2017-07-06', 10, '', 400000.00, 'Paid', 1499326615),
(1496559634, '2017-07-06', 10, '', 2775000.00, 'Paid', 1499326967),
(1496559635, '2017-07-06', 10, '', 2775000.00, 'Paid', 1499327444),
(1496559636, '2017-07-07', 10, '', 2000000.00, 'Bayar', 1499422891),
(1496559637, '2017-07-07', 12, '', 400000.00, 'Paid', 1499423455),
(1496559638, '2017-07-07', 12, '', 12000000.00, 'Proses', 1499423573),
(1496559639, '2017-07-07', 10, '', 2775000.00, 'Bayar', 1499424225),
(1496559640, '2017-07-07', 10, '', 400000.00, 'Bayar', 1499425773),
(1496559641, '2017-07-07', 10, 'haha', 12000000.00, 'Reject', 1499425872),
(1496559642, '2017-07-07', 10, '', 400000.00, 'Paid', 1499425958),
(1496559643, '2017-07-09', 10, '', 12000000.00, 'Paid', 1499586644);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `idPenjualan` int(10) NOT NULL,
  `idPembayaran` int(10) NOT NULL,
  `totalPenjualan` double(15,2) NOT NULL,
  `totalPembayaran` double(15,2) NOT NULL,
  `idUser` int(10) NOT NULL,
  `datePenjualan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`idPenjualan`, `idPembayaran`, `totalPenjualan`, `totalPembayaran`, `idUser`, `datePenjualan`) VALUES
(1, 2, 0.00, 0.00, 1, '0000-00-00'),
(2, 4, 100000.00, 100000.00, 1, '2017-06-05'),
(3, 5, 220000.00, 120000.00, 1, '2017-06-05'),
(4, 18, 15220000.00, 15000000.00, 1, '2017-07-05'),
(5, 19, 15420000.00, 200000.00, 1, '2017-07-05'),
(6, 20, 18420000.00, 3000000.00, 1, '2017-07-05'),
(7, 22, 26745000.00, 8325000.00, 1, '2017-07-06'),
(8, 24, 53520000.00, 26775000.00, 1, '2017-07-06'),
(9, 28, 56295000.00, 2775000.00, 1, '2017-07-06'),
(10, 27, 56695000.00, 400000.00, 1, '2017-07-06'),
(11, 31, 57095000.00, 400000.00, 1, '2017-07-07'),
(12, 35, 69095000.00, 12000000.00, 1, '2017-07-09'),
(13, 34, 69495000.00, 400000.00, 1, '2017-07-09'),
(14, 29, 72270000.00, 2775000.00, 1, '2017-07-09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `stock`
--

CREATE TABLE `stock` (
  `idStock` int(10) NOT NULL,
  `idBarang` int(10) NOT NULL,
  `masukStock` int(10) NOT NULL,
  `keluarStock` int(10) NOT NULL,
  `saldoStock` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `stock`
--

INSERT INTO `stock` (`idStock`, `idBarang`, `masukStock`, `keluarStock`, `saldoStock`) VALUES
(20, 22, 1, 0, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE `supplier` (
  `idSupplier` int(10) NOT NULL,
  `nameSupplier` varchar(30) NOT NULL,
  `alamatSupplier` text NOT NULL,
  `tlpnSupplier` varchar(18) NOT NULL,
  `emailSupplier` varchar(30) NOT NULL,
  `faxSupplier` varchar(16) NOT NULL,
  `pemilikSupplier` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`idSupplier`, `nameSupplier`, `alamatSupplier`, `tlpnSupplier`, `emailSupplier`, `faxSupplier`, `pemilikSupplier`) VALUES
(1, 'Asus Center', 'kajskj', '0890809', 'asus@gmail.com', '129089', 'Ahuang'),
(2, 'Toshiba', 'Medan', '0812633', 'toshiba@gmail.com', '1234', 'Acen'),
(3, 'Axio', 'Sumatra Utara', '081238123', 'axio@gmail.com', '1234', 'Axio dkk'),
(4, 'Lenovo', 'Sumatra Barat', '08128373', 'lenovo@gmail.com', '1234', 'Uda Rony'),
(5, 'Dell', 'Medan Sumut', '0812733', 'Dell@gmail.com', '018234', 'Akong');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `idUser` int(10) NOT NULL,
  `passwordUser` varchar(50) NOT NULL,
  `usernameUser` varchar(20) NOT NULL,
  `nameUser` varchar(40) NOT NULL,
  `emailUser` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`idUser`, `passwordUser`, `usernameUser`, `nameUser`, `emailUser`) VALUES
(1, 'e10adc3949ba59abbe56e057f20f883e', 'admin', 'Admin', 'addmin@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`idBarang`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`idCustomer`);

--
-- Indexes for table `detailpesanan`
--
ALTER TABLE `detailpesanan`
  ADD PRIMARY KEY (`idDetailpesanan`);

--
-- Indexes for table `merek`
--
ALTER TABLE `merek`
  ADD PRIMARY KEY (`idMerek`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`idPembayaran`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`idPemesanan`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`idPenjualan`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`idStock`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`idSupplier`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `idBarang` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `idCustomer` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `detailpesanan`
--
ALTER TABLE `detailpesanan`
  MODIFY `idDetailpesanan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `merek`
--
ALTER TABLE `merek`
  MODIFY `idMerek` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `idPembayaran` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `idPemesanan` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1496559644;
--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `idPenjualan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `idStock` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `idSupplier` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
