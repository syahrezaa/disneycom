<?php
	include"config/koneksi.php";
	
	session_destroy();
	echo"<script>
			window.location.assign('../disneycom')
		</script>";
?>
