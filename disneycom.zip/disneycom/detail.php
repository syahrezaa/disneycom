<!DOCTYPE HTML>
<?php
	session_start();
	include("config/koneksi.php");
?>
<html>
<head>
<title>Toko Komputer Disney COm</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link id="callCss" rel="stylesheet" href="themes/bootshop/bootstrap.min.css" media="screen"/>
    <link href="themes/css/base.css" rel="stylesheet" media="screen"/>
	
	<link href="themes/css/bootstrap-responsive.min.css" rel="stylesheet"/>
	<link href="themes/css/font-awesome.css" rel="stylesheet" type="text/css">
	
	<link href="themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
	
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="themes/images/ico/apple-touch-icon-57-precomposed.png">
	<style type="text/css" id="enject"></style>
</head>
<body>

<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
	<?php
		if($_SESSION['idCustomer']<>''){
			echo"
			<div class='span6'>Welcome!<strong> $_SESSION[nameCustomer]</strong></div>";
		}else{
			echo"
			<div class='span6'>Welcome di DisneyCom</div>";
		}
	?>
	<div class="span6">
	<div class="pull-right">
		<?php				
			$cek = mysql_query("SELECT * FROM detailpesanan 
								INNER JOIN pemesanan
									ON detailpesanan.idPemesanan = pemesanan.idPemesanan
								INNER JOIN barang
									ON detailpesanan.idBarang = barang.idBarang
								WHERE pemesanan.idCustomer='$_SESSION[idCustomer]'
									AND pemesanan.statusPemesanan = 'Open'");
			$jumlah = mysql_num_rows($cek);
			$subtotal=0;
			while($rc = mysql_fetch_array($cek)){
				$subtotal =  $subtotal + ($rc['hargaBarang']*$rc['qtyDetailpesanan']);
			}
			if($jumlah==0){
				echo"<a href='detail.php?mod=pesananku'><span class='btn btn-mini btn-primary'><i class='icon-shopping-cart icon-white'></i> [ $jumlah ] Item dikeranjang belanja </span> </a> ";
			}else{
				echo"<a href='detail.php?mod=pesananku'><span class='btn btn-mini btn-primary'><i class='icon-shopping-cart icon-white'></i> [ $jumlah ] Item dikeranjang belanja </span> </a> ";
			}
		?>
		<?php
		if($_SESSION['idCustomer']==''){
			echo"
			<a href='loginadmin.php'><span class=''>Login Admin</span></a>";
		}else{
			echo"";
		}
		?>
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="index.php"><img src="images/logo3.png" alt=""/></a>
	<form class="form-inline navbar-search" method="post" action="" >
		<input id="srchFld" class="srchTxt" type="text" />
		<button type="submit" id="submitButton" class="btn btn-primary">Go</button>
    </form>
      <ul id="topMenu" class="nav pull-right">
		<li class=""><a href="detail.php?mod=kontak">Kontak</a></li>
		<?php
		if($_SESSION['idCustomer']==''){
		?>
		<li class=""><a href="detail.php?mod=register">Register</a></li>
		<li class=""><a href="detail.php?mod=login" ><span class="btn btn-large btn-success">Login</span></a></li>
		<?php
		}else{
			echo"
				<li class=''><a href='detail.php?mod=pesananku'>Daftar Belanja</a></li>
				<li class=''><a href='detail.php?mod=pembayaran'>Pembayaran</a></li>
				<li class=''><a href='detail.php?mod=histori'>History</a></li>
				<li class=''><a href='logout.php'>Logout</a></li>";
		}
		?>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== -->


<div id="mainBody">
	<div class="container">
	<div class="row">
	
	<!-- Sidebar ================================================== -->
		<div id="sidebar" class="span3">
			<div class="well well-small">
			<?php				
				$cek = mysql_query("SELECT * FROM detailpesanan 
									INNER JOIN pemesanan
										ON detailpesanan.idPemesanan = pemesanan.idPemesanan
									INNER JOIN barang
										ON detailpesanan.idBarang = barang.idBarang
									WHERE pemesanan.idCustomer='$_SESSION[idCustomer]'
										AND pemesanan.statusPemesanan = 'Open'");
				$jumlah = mysql_num_rows($cek);
				$subtotal=0;
				while($rc = mysql_fetch_array($cek)){
					$subtotal =  $subtotal + ($rc['hargaBarang']*$rc['qtyDetailpesanan']);
				}
				if($jumlah==0){
					echo"
					<a id='myCart' href='detail.php?mod=pesananku'><img src='themes/images/ico-cart.png' alt='cart'>$jumlah item <span class='badge badge-warning pull-right'>Rp. 0</span></a>";
				}else{
					echo"<a id='myCart' href='detail.php?mod=pesananku'><img src='themes/images/ico-cart.png' alt='cart'>$jumlah item <span class='badge badge-warning pull-right'>Rp. $subtotal</span></a> ";
				}
			?>
			</div>
			<ul id="sideManu" class="nav nav-tabs nav-stacked">
				<li class="subMenu open"><a> Merek</a>
					<ul>
						<?php
							$merek = mysql_query("SELECT * FROM merek");
							while($m = mysql_fetch_array($merek)){
								echo"<li><a href='detail.php?mod=merek&id=$m[idMerek]'>$m[nameMerek]</a></li>";
							}		
						?>
					</ul>
				</li>
				
			</ul>
			<br/>
					
			<div class="thumbnail">
				<img src="themes/images/payment_methods.png" title="Bootshop Payment Methods" alt="Payments Methods">
				<div class="caption">
				  <h5>Metode Pembayaran</h5>
				</div>
			</div>
		</div>
	<!-- Sidebar end=============================================== -->
	
		<div class="span9">				
			
				<?php
					if($_GET['mod']=='pesananku'){
						include"pesananku.php";
					}elseif($_GET['mod']=='merek'){
						include"merek.php";
					}elseif($_GET['mod']=='kebijakan'){
						include"kebijakan.php";
					}elseif($_GET['mod']=='kontak'){
						include"kontak.php";
					}elseif($_GET['mod']=='pembayaran'){
						include"pembayaran.php";
					}elseif($_GET['mod']=='faq'){
						include"faq.php";
					}elseif($_GET['mod']=='histori'){
						include"histori.php";
					}elseif($_GET['mod']=='bayar'){
						include"pembayaran.php";
					}elseif($_GET['mod']=='login'){
						include"logincust.php";
					}elseif($_GET['mod']=='register'){
						include"register.php";
					}else{
						echo"
						<ul class='breadcrumb'>
							<li><a href='index.php'>Home</a> <span class='divider'>/</span></li>
							<li class='active'>Detail</li>
						</ul>	
						
						<div class='row'>";
							$barang = mysql_query("SELECT * FROM barang WHERE barang.idBarang='$_GET[id]'");
							$br = mysql_fetch_array($barang);
							echo"
							<div id='gallery' class='span3'>
								<img src='master/images/$br[imgBarang]' alt='' />
								<div id='differentview' class='moreOptopm carousel slide'>
									<div class='carousel-inner'>
									  <div class='item active'>
									   <a href='master/images/$br[imgBarang]'><img src='master/images/$br[imgBarang]' alt='' width='29%'/></a>
									  </div>
									</div>
								</div>	
							</div>
							
							
							<div class='span6'>
								<h3>$br[nameBarang]  </h3>
								<div id='list_cart'></div>
								<hr class=soft/>
								<form class='form-horizontal qtyFrm'>
								  <div class='control-group'>
									<label class='control-label'><span>Rp. $br[hargaBarang]</span></label>
									<div class='controls'>
									<input type='number' class='span1' id='qty' value='1'  placeholder='Qty.'/>";
									if($_SESSION['idCustomer']==''){
										echo"
											<button type='button' class='btn btn-large btn-primary pull-right'><a href='detail.php?mod=login&ids=$br[idBarang]'> Add to cart <i class=' icon-shopping-cart'></i></a></button>
										";
									}else{
										echo"
										<button type='button' class='btn btn-large btn-primary pull-right' id='addcart' idBarang='$br[idBarang]'> Add to cart <i class=' icon-shopping-cart'></i></button>";
									}
									echo"
									</div>
								  </div>
								</form>
								
								<hr class='soft'/>
								
								<p>
									$br[ketBarang].
								</p>
								
								<hr class='soft'/>
							</div>
							
							<div class='span9'>
								<h4 style='border-bottom:1px solid #f0f0f0;'>Produk Sejenis </h4>
								
								<ul class='thumbnails'>";
									$barang = mysql_query("SELECT * FROM barang ORDER BY idBarang LIMIT 3 ");
									while($br = mysql_fetch_array($barang)){									
										echo"								
										<li class='span3'>
										  <div class='thumbnail'>
											<a href='detail.php?id=$br[idBarang]'>
												<img src='master/images/$br[imgBarang]' alt='' />
											</a>
											<div class='caption'>
											  <h5>$br[nameBarang]<br/>
													Rp. $br[hargaBarang]
											  </h5>
											  <h4><a class='btn' href='detail.php?id=$br[idBarang]'>Lihat</a></h4>
											</div>
										  </div>
										</li>";
									}
								echo"
								</ul>
							</div>
							
						</div>";
					}				
				?>		
		</div>
		
	</div>
	</div>
</div>


<!------footer---->
<div  id="footerSection">
<div class="container">
	<div class="row">
		<div class="span3">
			<h5>ACCOUNT</h5>
			<a href="detail.php?mod=login">LOGIN</a>
			<a href="detail.php?mod=histori">ORDER HISTORY</a>
		 </div>
		<div class="span3">
			<h5>INFORMATION</h5>
			<a href="detail.php?mod=kontak">KONTAK</a>  
			<a href="detail.php?mod=kebijakan">KEBIJAKAN DAN PRIVASI</a> 
			<a href="detail.php?mod=faq">FAQ</a>
		 </div>
		<div id="socialMedia" class="span3 pull-right">
			<h5>SOCIAL MEDIA </h5>
			<a href="#"><img width="60" height="60" src="themes/images/facebook.png" title="facebook" alt="facebook"/></a>
			<a href="#"><img width="60" height="60" src="themes/images/twitter.png" title="twitter" alt="twitter"/></a>
			<a href="#"><img width="60" height="60" src="themes/images/youtube.png" title="youtube" alt="youtube"/></a>
		 </div> 
	 </div>
	<p>Disney COm © All rights Reseverd </p>
</div><!-- Container End -->
</div>


<script src="themes/js/jquery.js" type="text/javascript"></script>
<script src="themes/js/bootstrap.min.js" type="text/javascript"></script>
	<script>
	$(document).ready(function(){	  
		$("#addcart").click(function(){
			var idBarang 	= $(this).attr("idBarang");
			var qty 	= $("#qty").val();
			
			$.ajax({
				url: "aksi/addcart.php",
				data: "idBarang=" + idBarang + "&qty=" + qty,
				success: function(data){
					$("#list_cart").html(data);
				}
			});
			return false;
		});		
		$("#beli").click(function(){
			var ketPemesanan 	= $("#ketPemesanan").val();
			
			$.ajax({
				url: "aksi/addpemesanan.php",
				data: "ketPemesanan=" + ketPemesanan,
				success: function(data){
					$("#list_pemesanan").html(data);
				}
			});
			return false;
		});		
		
		$("#register").click(function(){
			var nameCustomer 	= $("#nameCustomer").val();
			if(nameCustomer==''){
				document.getElementById('nameCustomer').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var passwordCustomer 	= $("#passwordCustomer").val();
			if(passwordCustomer==''){
				document.getElementById('passwordCustomer').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var emailCustomer 	= $("#emailCustomer").val();
			if(emailCustomer==''){
				document.getElementById('emailCustomer').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var notlpnCustomer 	= $("#notlpnCustomer").val();
			if(notlpnCustomer==''){
				document.getElementById('notlpnCustomer').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var alamatCustomer 	= $("#alamatCustomer").val();
			if(alamatCustomer==''){
				document.getElementById('alamatCustomer').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var idBarang 	= $("#idBarang").val();
			$.ajax({
				url: "aksi/aksiregister.php",
				data: "nameCustomer=" + nameCustomer + "&passwordCustomer=" + passwordCustomer + "&emailCustomer=" + emailCustomer + "&notlpnCustomer=" + notlpnCustomer + "&alamatCustomer=" + alamatCustomer + "&idBarang=" + idBarang,
				success: function(data){
					$("#list_register").html(data);
				}
			});
			return false;
		});
		
		$("#loginom").click(function(){
			var idBarang 	= $("#idBarang").val();
			var usernameUser 	= $("#usernameUser").val();
			if(usernameUser==''){
				document.getElementById('usernameUser').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var passwordUser 	= $("#passwordUser").val();
			if(passwordUser==''){
				document.getElementById('passwordUser').style.border ='2px solid red';
				e.preventDefault(); 
			}
			$.ajax({
				url: "aksi/aksilogincust.php",
				data: "passwordUser=" + passwordUser + "&usernameUser=" + usernameUser + "&idBarang=" + idBarang ,
				success: function(data){
					$("#list_login").html(data);
				}
			});
			return false;
		});
		
			
		$('#files1').change(function() {
			function _(el){
				return document.getElementById(el);
			}
			
			var file = _("files1").files[0];
			if(file.size > 5500000){
				alert("Maksimum File Upload 5 MB");
				e.preventDefault();
			}
			
			
				if(file.name==''){
					alert("File masih kosong");
				}else{
					var formdata = new FormData();
					formdata.append("files1", file);
					var ajax = new XMLHttpRequest();
					ajax.upload.addEventListener("progress", progressHandler, false);
					ajax.addEventListener("load", completeHandler, false);
					ajax.addEventListener("error", errorHandler, false);
					ajax.addEventListener("abort", abortHandler, false);
					ajax.open("POST", "aksi/uploadbukti.php");
					ajax.send(formdata);
					 
					$('#progressupload1').show(); 
				}
			
				function progressHandler(event){
					_("loaded_n_total1").innerHTML = "";
					var percent = (event.loaded / event.total) * 100;
					_("progressBar1").value = Math.round(percent);
					_("status1").innerHTML = "";
					
				}
				function completeHandler(event){
					_("status1").innerHTML = event.target.responseText;
				}
				function errorHandler(event){
					_("status1").innerHTML = "Upload Failed";
				}
				function abortHandler(event){
					_("status1").innerHTML = "Upload Aborted";
				}
			
		});
		
		$(".prosesbayar").click(function(){
			var idPemesanan 	= $(this).attr("idPemesanan");
			var kdPemesanan 	= $(this).attr("kdPemesanan");
			var total 	= $(this).attr("total");
			document.getElementById('idPemesanan').value =idPemesanan;
			document.getElementById('kdPemesanan').value =kdPemesanan;
			document.getElementById('jumlahPembayaran').value =total;
			
			$.ajax({
				url: "aksi/cekpesanan.php",
				data: "idPemesanan=" + idPemesanan,
				success: function(data){
					$("#listdetail").html(data);
				}
			});
			return false;
			
		});
		
		$("#bayar").click(function(){
			var idPemesanan 	= $("#idPemesanan").val();
			if(idPemesanan==''){
				document.getElementById('idPemesanan').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var jumlahPembayaran 	= $("#jumlahPembayaran").val();
			if(jumlahPembayaran==''){
				document.getElementById('jumlahPembayaran').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var ketPembayaran 	= $("#ketPembayaran").val();
			
			
			$.ajax({
				url: "aksi/addpembayaran.php",
				data: "jumlahPembayaran=" + jumlahPembayaran + "&idPemesanan=" + idPemesanan + "&ketPembayaran=" + ketPembayaran  ,
				success: function(data){
					$("#list_pembayaran").html(data);
				}
			});
			return false;
		});
		
		$(".hapusbarang").click(function(){
			var idDetailpesanan 	= $(this).attr("idDetailpesanan");
			
			
			$.ajax({
				url: "aksi/hapusbarang.php",
				data: "idDetailpesanan=" + idDetailpesanan,
				success: function(data){
					location.reload();
				}
			});
			return false;
		});
	});
	</script>
    
</body>
</html>

