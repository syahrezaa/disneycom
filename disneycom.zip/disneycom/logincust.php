<!DOCTYPE HTML>
<?php
	session_start();
	include("config/koneksi.php");
?>
<table class="table table-bordered">
	<tr><th> Saya sudah punya akun  </th></tr>
	 <tr> 
	 <td>
		<form class="form-horizontal">
			<div class="control-group">
			  <label class="control-label" for="inputUsername">Username</label>
			  <div class="controls">
				<input type="text" id="usernameUser" placeholder="Username">
				<input type="hidden" id="idBarang" placeholder="Username" value='<?php echo"$_GET[ids]";?>'>
			  </div>
			</div>
			<div class="control-group">
			  <label class="control-label" for="inputPassword1">Password</label>
			  <div class="controls">
				<input type="password" id="passwordUser" placeholder="Password">
			  </div>
			</div>
			<div class="control-group">
			  <div class="controls">
				<button type="button" class="btn" id='loginom' >Sign in</button> OR <a href="detail.php?mod=register&id=<?php echo$_GET['ids'];?>" class="btn">Register Now!</a>
			  </div>
			</div>
			<div class="control-group">
				<div id='list_login'></div>
				<div class="controls">
				  <a href="#" style="text-decoration:underline">Lupa password ?</a>
				</div>
			</div>
		</form>
	  </td>
	  </tr>
</table>		

