<h1>Kunjungi Kami</h1>
<hr class="soften"/>	
<div class="row">
	<div class="span4">
	<h4>Kontak kami</h4>
	<p>	Disney Com,<br/> Panam
		<br/><br/>
		disneycom@gmail.com<br/>
		Tel 0761 098980<br/>
		Fax 0761 098980
	</p>		
	</div>
		
	<div class="span4">
	<h4>Jam Buka</h4>
		<h5> Senin - Jumat</h5>
		<p>09:00am - 09:00pm</p>
		<h5>Sabtu</h5>
		<p>09:00am - 07:00pm</p>
		<h5>Minggu</h5>
		<p>12:30pm - 06:00pm</p>
	</div>
</div>
	