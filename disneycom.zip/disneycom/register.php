<!DOCTYPE HTML>
<?php
	session_start();
	include("config/koneksi.php");
?>
<ul class='breadcrumb'>
	<li><a href='index.php'>Home</a> <span class='divider'>/</span></li>
	<li class='active'>Registrasi</li>
</ul>
	<div class="well">
	<form class="form-horizontal" >
		<h4>Biodata Anda</h4>
		<div class="control-group">
			<label class="control-label" for="inputFname1">Nama Lengkap <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="nameCustomer" placeholder="Nama Lengkap">
				<input type="hidden" id="idBarang" placeholder="Username" value='<?php echo"$_GET[id]";?>'>
			</div>
		 </div>
		 
		<div class="control-group">
			<label class="control-label" for="input_email">Email <sup>*</sup></label>
			<div class="controls">
				<input type="text" id="emailCustomer" placeholder="Email">
			</div>
		</div>	  
		<div class="control-group">
			<label class="control-label" for="inputPassword1">Password <sup>*</sup></label>
			<div class="controls">
				<input type="password" id="passwordCustomer" placeholder="Password">
			</div>
		</div>	  
		
		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Alamat</label>
			<div class="controls">
			  <textarea name="alamatCustomer" id="alamatCustomer" cols="26" rows="3" placeholder='Alamat'></textarea>
			</div>
		</div>
		
		<div class="control-group">
			<label class="control-label" for="mobile">Telpn </label>
			<div class="controls">
			  <input type="text"  name="notlpnCustomer" id="notlpnCustomer" placeholder="Telepon"/> 
			</div>
		</div>
		
	<p><sup>*</sup>Tidak Boleh Kosong	</p>
	
	<div class="control-group">
		<div id='list_register'></div>
		<div class="controls">
			<input class="btn btn-large btn-success" type="button" id='register' value="Register" />
		</div>
	</div>		
	</form>	
</div>	
