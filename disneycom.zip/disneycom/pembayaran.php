<?php
	echo"
		<ul class='breadcrumb'>
			<li><a href='index.php'>Home</a> <span class='divider'>/</span></li>
			<li class='active'>Pembayaran</li>
		</ul>";
	
	echo"	
		<div class='table-responsive'>
			<h3>Transaksi Pemesanan</h3>
			<table class='table table-bordered'>
				<thead>
					<tr>
					  <th>Kd Pemesanan</th>
					  <th>Tanggal</th>
					  <th>Jumlah Item</th>
					  <th>Total</th>
					  <th>Aksi</th>
					</tr>
				</thead>
				<tbody>";
					$model = mysql_query("SELECT * FROM pemesanan
											WHERE pemesanan.idCustomer='$_SESSION[idCustomer]'
												AND pemesanan.statusPemesanan='Proses'");
					$no="";

					while($rb = mysql_fetch_array($model)){
						$no++;
						
						$models = mysql_query("SELECT * FROM detailpesanan 
												INNER JOIN barang
													ON detailpesanan.idBarang = barang.idBarang
												WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
						
						$jumlahitem = mysql_num_rows($models);
						$total="";
						while($rbs = mysql_fetch_array($models)){
							
							$subtotal = $rbs['hargaBarang']* $rbs['qtyDetailpesanan'];
							
							$total = $total + $subtotal;
						}
						$hasil = number_format($total,2,",",".");
						
						echo"
							<tr>
								<td>$rb[kdPemesanan]</td>
								<td>$rb[datePemesanan]</td>
								<td>
									$jumlahitem
								</td>
								<td>Rp. $hasil</td>
								<td><a href='javascript:;' id='prosesbayar' kdPemesanan='$rb[kdPemesanan]' idPemesanan='$rb[idPemesanan]' total='$total' class='btn prosesbayar'>Proses Bayar</a></td>
								
							</tr>";
					}
				echo"
				</tbody>
			</table>
			
			<table class='table table-bordered'>
				<tr><th>Isi Data Pembayaran </th></tr>
				<tr> 
					<td>
						<form class='form-horizontal'>
							<div class='control-group'>
								<label class='control-label' for='inputCountry'>Kd Pemesanan </label>
								<div class='controls'>
									<input type='hidden' value='' id='idPemesanan'>
									<input type='text' value='' id='kdPemesanan' disabled>
								</div>
							</div>
							<div class='control-group'>
								<label class='control-label' for='inputCountry'>Jumlah Pembayaran </label>
								<div class='controls'>
									<input type='text' value='' id='jumlahPembayaran'>
								</div>
							</div>
							<div class='control-group'>
								<label class='control-label' for='inputCountry'>Bukti Transfer </label>
								<div class='controls'>
									<input type='file' value='' id='files1' name='files1'>
								</div>
								<div id='progressupload1' style='display:none;'>
									<progress id='progressBar1' value='0' max='100' style='width:100px;margin-left:5px;'></progress>
									<div id='status1'></div>
									<p id='loaded_n_total1'></p>
								</div>
							</div>
							
							<div class='control-group' id='listdetail'></div>
							
							<div class='control-group'>
								<div class='controls'>
									<div id='list_pembayaran'></div>
									<button type='button' id='bayar' class='btn'>Simpan  </button>
								</div>
							</div>
						</form>				  
					</td>
				</tr>
			</table>		
		</div>

	";
?>