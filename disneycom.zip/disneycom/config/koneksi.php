<?php
	error_reporting(0);
	session_start();
	date_default_timezone_set("Asia/Bangkok");	
	$date	= date("Y-m-d");
	$time 	= date("H:i:s"); 
	
	$rj_id		= "SP40514";
	$rj_pin		= "800833";

	
	$url_app	= "127.0.0.1";
	$url_web	= "127.0.0.1";
	
	$server 	= "127.0.0.1";
	$username	= "root";
	$password 	= ""; 
	$database 	= "db_ecommers";

	// Koneksi dan memilih database di server
	mysql_connect($server,$username,$password) or die("Koneksi gagal");
	mysql_select_db($database) or die("Database tidak bisa dibuka");
?>