<ul class="breadcrumb">
	<li><a href="index.php">Home</a> <span class="divider">/</span></li>
	<li class="active">Kebijakan dan Privasi</li>
</ul>
<h3> Kebijaka dan Privasi</h3>	
<hr class="soft"/>
<h5>Syarat belanja</h5><br/>
<p>
	kami menyediakan barang-barang yang berkualitas sehingga kami mempunyai persyaratan dalam proses pembelian diwebsite kami. seperti anda harus mendaftarkan akun anda terlebih dahulu.
</p>
