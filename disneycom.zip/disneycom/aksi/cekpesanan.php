<?php
	include "../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	echo"
		<table class='table table-bordered'>
		<thead>
			<tr>
			  <th>Product</th>
			  <th>Description</th>
			  <th>Quantity</th>
			  <th>Price</th>
			  <th>Total</th>
			</tr>
		</thead>
		<tbody>";
			$model = mysql_query("SELECT * FROM detailpesanan 
									INNER JOIN barang
										ON detailpesanan.idBarang = barang.idBarang
									WHERE detailpesanan.idPemesanan='$_GET[idPemesanan]'");
			$no="";
			$total="";
			while($rb = mysql_fetch_array($model)){
				$no++;
				$subtotal = $rb['hargaBarang']* $rb['qtyDetailpesanan'];
				$hasi = number_format($subtotal,2,",",".");
				$hargaBarang = number_format($rb['hargaBarang'],2,",",".");
				echo"
					<tr>
						<td><img src='master/images/$rb[imgBarang]' width='60' ></td>
						<td>$rb[ketBarang] </td>
						<td>
							$rb[qtyDetailpesanan]
						</td>
						<td>$hargaBarang</td>
						<td>$hasi</td>
						
					</tr>";
			}
		echo"
		</tbody>
	</table>
	";
	
	

?>