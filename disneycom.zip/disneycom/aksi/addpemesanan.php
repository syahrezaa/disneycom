<?php
	include "../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	$cek = mysql_fetch_array(mysql_query("SELECT * FROM pemesanan WHERE pemesanan.idCustomer='$_SESSION[idCustomer]' AND pemesanan.statusPemesanan='Open'"));
	
	$model = mysql_query("SELECT * FROM detailpesanan 
							INNER JOIN barang
								ON detailpesanan.idBarang = barang.idBarang
							WHERE detailpesanan.idPemesanan='$cek[idPemesanan]'");

	$total="";
	while($rb = mysql_fetch_array($model)){

		$subtotal = $rb['hargaBarang']* $rb['qtyDetailpesanan'];
		$total = $total + $subtotal;
	}
	
	mysql_query("UPDATE pemesanan SET totalPemesanan = '$total',
										statusPemesanan = 'Proses'
										WHERE idPemesanan = '$cek[idPemesanan]'");
								
												
	
	echo"<script>
			location.assign('../disneycom');
		</script>";
	exit;
	
	

?>