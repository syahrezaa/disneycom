<?php
	include "../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	mysql_query("delete from detailpesanan WHERE idDetailpesanan = '$_GET[idDetailpesanan]'");
	
	echo"<script>
			location.assign('../disneycom');
		</script>";
	exit;
	
	

?>