<?php
	include "../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	
	$img=md5("$_GET[passwordCustomer]");
	mysql_query("INSERT INTO customer(
									nameCustomer,
									passwordCustomer,
									emailCustomer,
									notlpnCustomer,
									alamatCustomer
								)VALUES(
									'$_GET[nameCustomer]',
									'$img',
									'$_GET[emailCustomer]',
									'$_GET[notlpnCustomer]',
									'$_GET[alamatCustomer]'
								)");
								
	$rkonsumen	= mysql_fetch_array(mysql_query("SELECT *
												FROM customer 
												WHERE customer.emailCustomer ='$_GET[emailCustomer]'"));
	
	session_start();		
	$_SESSION['idCustomer']   	= $rkonsumen['idCustomer'];		
	$_SESSION['nameCustomer']   = $rkonsumen['nameCustomer'];	

	if($_GET['idBarang']<>''){
		$timess = time();
		mysql_query("INSERT INTO pemesanan(
							kdPemesanan,
							datePemesanan,
							idCustomer
						)VALUES(
							'$timess',
							'$date',
							'$_SESSION[idCustomer]'
						)");
						
		$ceks = mysql_fetch_array(mysql_query("SELECT * FROM pemesanan WHERE pemesanan.idCustomer='$_SESSION[idCustomer]' AND pemesanan.statusPemesanan='Open' ORDER BY idPemesanan DESC LIMIT 1"));
		mysql_query("INSERT INTO detailpesanan(
										idBarang,
										idPemesanan,
										qtyDetailpesanan
									)VALUES(
										'$_GET[idBarang]',
										'$ceks[idPemesanan]',
										'1'
									)");	
	}	
				
	echo "<script>
			location.assign('../disneycom/detail.php?mod=pesananku');
		</script>";
	exit;			

?>