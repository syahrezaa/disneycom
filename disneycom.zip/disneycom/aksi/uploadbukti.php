<?php
include "../config/koneksi.php";
?>
<?php
$fileName = $_FILES["files1"]["name"]; // The file name
$fileTmpLoc = $_FILES["files1"]["tmp_name"]; // File in the PHP tmp folder
$fileType = $_FILES["files1"]["type"]; // The type of file it is
$fileSize = $_FILES["files1"]["size"]; // File size in bytes
$fileErrorMsg = $_FILES["files1"]["error"]; // 0 for false... and 1 for true
$final_width_of_image = 40;
$path_to_image_directory = '../master/images/';
$path_to_thumbs_directory = '../master/images/thumbnail/';
$uploadOk = 1;

$FileName2			= strtolower($_FILES['files1']['name']);

$ImageExt			= substr($FileName2, strrpos($FileName2, '.'));
$extension 			= explode(".", $FileName2);
$date = date("dmY");
$timenow = date("His");
$NewFileName2 = preg_replace(array('/\s/', '/\.[\.]+/', '/[^\w_\.\-]/'), array('_', '.', ''), strtolower($date));
$NewFileName = $NewFileName2.$timenow.$FileName2;

$NewFileName3 = $NewFileName2.$extension[0];
if (!$fileTmpLoc) { // if file not chosen
    echo "ERROR: Please browse for a file before clicking the upload button.";
    exit();
}

if ($_FILES["files1"]["size"] > 50000000) {
    echo "
	<script>
		alert('Sorry, your file is too large.');
	</script>";
	$uploadOk = 0;
}

if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
} else {
	if(move_uploaded_file($fileTmpLoc, "../master/images/$NewFileName")){	
				
		$tn = "<img src='master/images/$NewFileName' alt='image' width=100%/>";
		
		echo "<div id='deleteimg$NewFileName'><input type='hidden' name='ketPembayaran' id='ketPembayaran' value='$NewFileName'> $tn <span class='pull-right'><a href='javascript:;' imgPostdelgaleri='$NewFileName' style='color:#d8d8d8;' id='imgPostdelgaleri'><i class='fa fa-times'></i></a></span></div>";
	
	
		echo "
		<script>
			alert('Sorry, your file is too large.');
		</script>";
	} else {
		echo "move_uploaded_file function failed";
	}
}
?>