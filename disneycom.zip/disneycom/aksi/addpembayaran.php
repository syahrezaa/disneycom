<?php
	include "../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	
	mysql_query("INSERT INTO pembayaran(
									datePembayaran,
									jumlahPembayaran,
									idPemesanan,
									ketPembayaran
								)VALUES(
									'$date',
									'$_GET[jumlahPembayaran]',
									'$_GET[idPemesanan]',
									'$_GET[ketPembayaran]'
								)");
								
	mysql_query("UPDATE pemesanan SET statusPemesanan ='Bayar' WHERE idPemesanan='$_GET[idPemesanan]'");											
	
	echo"<script>
			location.assign('../disneycom');
		</script>";
	exit;
	
	

?>