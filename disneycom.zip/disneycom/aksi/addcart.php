<?php
	include "../config/koneksi.php";
	date_default_timezone_set("Asia/Jakarta");		
	$tanggalInformasi = date("Y-m-d H:i:s");	
// Input Information
	$timess = time();
	$cek = mysql_fetch_array(mysql_query("SELECT * FROM pemesanan WHERE pemesanan.idCustomer='$_SESSION[idCustomer]' AND pemesanan.statusPemesanan='Open'"));
	
	if($cek['idPemesanan']==''){
		
		mysql_query("INSERT INTO pemesanan(
										kdPemesanan,
										datePemesanan,
										idCustomer,
										ketPemesanan,
										totalPemesanan
									)VALUES(
										'$timess',
										'$date',
										'$_SESSION[idCustomer]',
										'$_GET[ketPemesanan]',
										'$_GET[totalPemesanan]'
									)");
	}
	$ceks = mysql_fetch_array(mysql_query("SELECT * FROM pemesanan WHERE pemesanan.idCustomer='$_SESSION[idCustomer]' AND pemesanan.statusPemesanan='Open' ORDER BY idPemesanan DESC LIMIT 1"));
	mysql_query("INSERT INTO detailpesanan(
									idBarang,
									idPemesanan,
									qtyDetailpesanan
								)VALUES(
									'$_GET[idBarang]',
									'$ceks[idPemesanan]',
									'$_GET[qty]'
								)");	
												
	
	echo"<script>
			location.assign('../disneycom');
		</script>";
	exit;
	
	

?>