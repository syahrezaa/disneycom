<?php
	include"../config/koneksi.php";

	function anti_injection($data){
		$filter 	= mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
		return $filter;
	}

	$user 	= $_GET['usernameUser'];
	$pass	= md5($_GET['passwordUser']);
		

	$rEmployee	= mysql_fetch_array(mysql_query("SELECT *
												FROM user 
												WHERE user.usernameUser ='$_GET[usernameUser]'"));
	
	
	$ketemu		= mysql_num_rows(mysql_query("SELECT *
												FROM user 
												WHERE user.usernameUser ='$_GET[usernameUser]'"));
	if($rEmployee['idUser']==''){	
		echo"<p>Username is Not Registered ..!!!</p>";
		exit;
	}elseif($rEmployee['idUser']<>''){
		if($_GET['usernameUser']<>'' AND $_GET['passwordUser']<>''){
			if (($ketemu > 0) AND ($rEmployee['passwordUser']==$pass)){
				session_start();		
				$_SESSION['idUser']   			= $rEmployee['idUser'];
				
				
				
				echo "<script>
						location.assign('../disneycom/master');
					</script>";
				exit;
			}elseif (($ketemu > 0) AND ($rEmployee['passwordUser']<>$pass)){
				echo"The Password You've Entered is Incorrect...!!!";
				exit;
			}
		}	
	}
		
?>