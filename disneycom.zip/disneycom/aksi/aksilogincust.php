<?php
	include"../config/koneksi.php";

	function anti_injection($data){
		$filter 	= mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
		return $filter;
	}

	$user 	= $_GET['usernameUser'];
	$pass	= md5($_GET['passwordUser']);
		

	$rkonsumen	= mysql_fetch_array(mysql_query("SELECT *
												FROM customer 
												WHERE customer.emailCustomer ='$_GET[usernameUser]'"));
	
	
	$ketemu		= mysql_num_rows(mysql_query("SELECT *
												FROM customer 
												WHERE customer.emailCustomer ='$_GET[usernameUser]'"));
	if($rkonsumen['idCustomer']==''){	
		echo"<p>Username is Not Registered ..!!!</p>";
		exit;
	}elseif($rkonsumen['idCustomer']<>''){
		if($_GET['usernameUser']<>'' AND $_GET['passwordUser']<>''){
			if (($ketemu > 0) AND ($rkonsumen['passwordCustomer']==$pass)){
				session_start();		
				$_SESSION['idCustomer']   			= $rkonsumen['idCustomer'];
				$_SESSION['nameCustomer']   		= $rkonsumen['nameCustomer'];
				
				if($_GET['idBarang']<>''){
					$timess = time();
					mysql_query("INSERT INTO pemesanan(
										kdPemesanan,
										datePemesanan,
										idCustomer
									)VALUES(
										'$timess',
										'$date',
										'$_SESSION[idCustomer]'
									)");
									
					$ceks = mysql_fetch_array(mysql_query("SELECT * FROM pemesanan WHERE pemesanan.idCustomer='$_SESSION[idCustomer]' AND pemesanan.statusPemesanan='Open' ORDER BY idPemesanan DESC LIMIT 1"));
					mysql_query("INSERT INTO detailpesanan(
													idBarang,
													idPemesanan,
													qtyDetailpesanan
												)VALUES(
													'$_GET[idBarang]',
													'$ceks[idPemesanan]',
													'1'
												)");	
				}
				
				
				echo "<script>
						location.assign('../disneycom/detail.php?mod=pesananku');
					</script>";
				exit;
			}elseif (($ketemu > 0) AND ($rkonsumen['passwordCustomer']<>$pass)){
				echo"The Password You've Entered is Incorrect...!!! ";
				exit;
			}
		}	
	}
		
?>