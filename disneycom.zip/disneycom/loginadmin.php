<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login/register</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

   <div class="container" style='margin-top:100px;'>
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Silahkan Login Administrator</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="usernameUser" id='usernameUser' type="text" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="passwordUser" id='passwordUser' type="password" value="">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                    </label>
                                </div>
                                <div id="list_login"></div>
                                <a href="javascript:;" id='loginom' class="btn btn-lg btn-success btn-block">Login</a>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script>
	$(document).ready(function(){	
		
		$("#loginom").click(function(){
			var passwordUser 	= $("#passwordUser").val();
			if(passwordUser==''){
				document.getElementById('passwordUser').style.border ='2px solid red';
				e.preventDefault(); 
			}
			var usernameUser 	= $("#usernameUser").val();
			if(usernameUser==''){
				document.getElementById('usernameUser').style.border ='2px solid red';
				e.preventDefault(); 
			}
			$.ajax({
				url: "aksi/aksiloginadmin.php",
				data: "passwordUser=" + passwordUser + "&usernameUser=" + usernameUser ,
				success: function(data){
					$("#list_login").html(data);
				}
			});
			return false;
		});
		
	});
	
	</script>
</body>

</html>
