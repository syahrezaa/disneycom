<?php
	echo"
		<div class='table-responsive'>
			<h3>Transaksi</h3>
			<table class='table table-bordered table-hover table-striped'>
				<thead>
					<tr>
						<th>No.</th>
						<th>Tanggal</th>
						<th>Kode Pemesanan</th>
						<th>Total</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>";
					$model = mysql_query("SELECT * FROM pemesanan
											WHERE pemesanan.idCustomer='$_SESSION[idCustomer]'");
					$no="";
					$total="";
					while($rb = mysql_fetch_array($model)){
						$no++;
						$cekbayar = mysql_fetch_array(mysql_query("SELECT * FROM pembayaran WHERE pembayaran.idPemesanan = '$rb[idPemesanan]'"));
						
						echo"
							<tr>
								<td>$no</td>
								<td>$rb[datePemesanan]</td>
								<td>
									<a href='javascript:;' style='color:blue' data-toggle='modal' data-target='#myModal$rb[kdPemesanan]'>$rb[kdPemesanan]</a>
									<!-- Modal -->
									  <div class='modal fade' id='myModal$rb[kdPemesanan]' role='dialog'>
										<div class='modal-dialog'>
										
										  <!-- Modal content-->
										  <div class='modal-content'>
											<div class='modal-header'>
											  <button type='button' class='close' data-dismiss='modal'>&times;</button>
											  <h4 class='modal-title'>Detail Pesanan</h4>
											</div>
											<div class='modal-body'>
											  <table class='table table-bordered'>
												<thead>
													<tr>
													  <th>Product</th>
													  <th>Description</th>
													  <th>Quantity</th>
													  <th>Price</th>
													  <th>Total</th>
													</tr>
												</thead>
												<tbody>";
													$models = mysql_query("SELECT * FROM detailpesanan 
																			INNER JOIN barang
																				ON detailpesanan.idBarang = barang.idBarang
																			WHERE detailpesanan.idPemesanan='$rb[idPemesanan]'");
													$nos="";
													$totals="";
													while($rbs = mysql_fetch_array($models)){
														$nos++;
														$subtotals = $rbs['hargaBarang']* $rbs['qtyDetailpesanan'];
														$hasis = number_format($subtotals,2,",",".");
														$hargaBarangs = number_format($rbs['hargaBarang'],2,",",".");
														echo"
															<tr>
																<td><img src='master/images/$rbs[imgBarang]' width='60' ></td>
																<td>$rbs[ketBarang] </td>
																<td>
																	$rbs[qtyDetailpesanan]
																</td>
																<td>Rp. $hargaBarangs</td>
																<td>Rp. $hasis</td>
																
															</tr>";
														$totals = $totals + $subtotals;
													}
													
														$hasils = number_format($totals,2,",",".");
												echo"<tr>
														<td colspan=4 style='text-align:right'>Total</td>
														<td >Rp. $hasils</td>
														
													</tr>
												</tbody>
											</table>
											</div>
											<div class='modal-footer'>
											  <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
											</div>
										  </div>
										  
										</div>
									  </div>
									
								</td>
								<td>Rp. $hasils</td>
								<td>$rb[statusPemesanan]</td>
								
							</tr>";
					}
				echo"
				</tbody>
			</table>
		</div>
		
		

	";
?>