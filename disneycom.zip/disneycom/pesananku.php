<?php
	echo"
		<ul class='breadcrumb'>
			<li><a href='index.php'>Home</a> <span class='divider'>/</span></li>
			<li class='active'>Pesanan Barang</li>
		</ul>";
		
	$cek = mysql_fetch_array(mysql_query("SELECT * FROM pemesanan WHERE pemesanan.idCustomer='$_SESSION[idCustomer]' AND pemesanan.statusPemesanan='Open'"));
	if($cek['idPemesanan']==0){
		echo"<div class='add-cart'>								
				<h4><a href='index.php'>Silahkan memilih dan memasukan pesanan anda di cart/keranjang</a></h4>
			</div>";
	}else{
	echo"	
		<div class='table-responsive'>
			<h3>Total Transaksi</h3>
			<table class='table table-bordered'>
				<thead>
					<tr>
					  <th>Product</th>
					  <th>Description</th>
					  <th>Quantity/Update</th>
					  <th>Price</th>
					  <th>Total</th>
					</tr>
				</thead>
				<tbody>";
					$model = mysql_query("SELECT * FROM detailpesanan 
											INNER JOIN pemesanan
												ON detailpesanan.idPemesanan = pemesanan.idPemesanan
											INNER JOIN barang
												ON detailpesanan.idBarang = barang.idBarang
											WHERE pemesanan.idCustomer='$_SESSION[idCustomer]'
												AND pemesanan.statusPemesanan='Open'");
					$no="";
					$total="";
					while($rb = mysql_fetch_array($model)){
						$no++;
						$subtotal = $rb['hargaBarang']* $rb['qtyDetailpesanan'];
						$hasi = number_format($subtotal,2,",",".");
						$hargaBarang = number_format($rb['hargaBarang'],2,",",".");
						echo"
							<tr>
								<td><img src='master/images/$rb[imgBarang]' width='60' ></td>
								<td>$rb[ketBarang] </td>
								<td>
									<div class='input-append'>
										<input class='span1 qtyDetailpesanan' style='max-width:34px' value='$rb[qtyDetailpesanan]' id='qtyDetailpesanan' idDetailpesanan='$rb[idDetailpesanan]' size='16' type='text' disabled>
										<button class='btn btn-danger hapusbarang' type='button' id='hapusbarang' idDetailpesanan='$rb[idDetailpesanan]'><i class='icon-remove icon-white'></i></button>				
									</div>
								</td>
								<td>$hargaBarang</td>
								<td>$hasi</td>
								
							</tr>";
						$total = $total + $subtotal;
					}
					
						$hasil = number_format($total,2,",",".");
				echo"<tr>
						<td colspan=4 style='text-align:right'>Total</td>
						<td class='label label-important' style='display:block'>Rp. $hasil</td>
						
					</tr>
				</tbody>
			</table>
			
			<div class='controls'>
				<div id='list_pemesanan'></div>
				<button type='button' id='beli' class='btn'>Simpan  </button>
			</div>
			
			
		</div>

	";
	}
?>