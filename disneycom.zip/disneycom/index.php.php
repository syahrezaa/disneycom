<!DOCTYPE HTML>
<?php
	session_start();
	include("config/koneksi.php");
?>
<html>
<head>
<title>Toko Komputer Disney Com</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link id="callCss" rel="stylesheet" href="themes/bootshop/bootstrap.min.css" media="screen"/>
    <link href="themes/css/base.css" rel="stylesheet" media="screen"/>
	
	<link href="themes/css/bootstrap-responsive.min.css" rel="stylesheet"/>
	<link href="themes/css/font-awesome.css" rel="stylesheet" type="text/css">
	
	<link href="themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
	
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="themes/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="themes/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="themes/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="themes/images/ico/apple-touch-icon-57-precomposed.png">
	<style type="text/css" id="enject"></style>
</head>
<body>

<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
	<?php
		if($_SESSION['idCustomer']<>''){
			echo"
			<div class='span6'>Welcome!<strong> $_SESSION[nameCustomer]</strong></div>";
		}else{
			echo"
			<div class='span6'>Welcome di DisneyCom</div>";
		}
	?>
	<div class="span6">
	<div class="pull-right">
		<?php				
			$cek = mysql_query("SELECT * FROM detailpesanan 
								INNER JOIN pemesanan
									ON detailpesanan.idPemesanan = pemesanan.idPemesanan
								INNER JOIN barang
									ON detailpesanan.idBarang = barang.idBarang
								WHERE pemesanan.idCustomer='$_SESSION[idCustomer]'
									AND pemesanan.statusPemesanan = 'Open'");
			$jumlah = mysql_num_rows($cek);
			$subtotal=0;
			while($rc = mysql_fetch_array($cek)){
				$subtotal =  $subtotal + ($rc['hargaBarang']*$rc['qtyDetailpesanan']);
			}
			if($jumlah==0){
				echo"<a href='detail.php?mod=pesananku'><span class='btn btn-mini btn-primary'><i class='icon-shopping-cart icon-white'></i> [ $jumlah ] Item dikeranjang belanja </span> </a> ";
			}else{
				echo"<a href='detail.php?mod=pesananku'><span class='btn btn-mini btn-primary'><i class='icon-shopping-cart icon-white'></i> [ $jumlah ] Item dikeranjang belanja </span> </a> ";
			}
		?>
		<?php
		if($_SESSION['idCustomer']==''){
			echo"
			<a href='loginadmin.php'><span class=''>Login Admin</span></a>";
		}else{
			echo"";
		}
		?>
	</div>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="index.php"><img src="images/logo3.png" alt=""/></a>
	<form class="form-inline navbar-search" method="post" action="" >
		<input id="srchFld" class="srchTxt" type="text" />
		<button type="submit" id="submitButton" class="btn btn-primary">Go</button>
    </form>
    <ul id="topMenu" class="nav pull-right">
		<li class=""><a href="detail.php?mod=kontak">Kontak</a></li>
		<?php
		if($_SESSION['idCustomer']==''){
		?>
		<li class=""><a href="detail.php?mod=register">Register</a></li>
		<li class=""><a href="detail.php?mod=login" ><span class="btn btn-large btn-success">Login</span></a></li>
		<?php
		}else{
			echo"
				<li class=''><a href='detail.php?mod=pesananku'>Daftar Belanja</a></li>
				<li class=''><a href='detail.php?mod=pembayaran'>Pembayaran</a></li>
				<li class=''><a href='detail.php?mod=histori'>History</a></li>
				<li class=''><a href='logout.php'>Logout</a></li>";
		}
		?>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== -->

<div id="carouselBlk">
	<div id="myCarousel" class="carousel slide">
		<div class="carousel-inner">
		  <div class="item active">
		  <div class="container">
			<a href="register.html"><img style="width:100%" src="themes/images/carousel/11.png" alt="special offers"/></a>
			
		  </div>
		  </div>
		  <div class="item">
		  <div class="container">
			<a href="register.html"><img style="width:100%" src="themes/images/carousel/12.png" alt=""/></a>
				
		  </div>
		  </div>
		  <div class="item">
		  <div class="container">
			<a href="register.html"><img src="themes/images/carousel/13.png" alt=""/></a>
			
		  </div>
		  </div>
		  
		</div>
		<a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
		<a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
	  </div> 
</div>

<div id="mainBody">
	<div class="container">
	<div class="row">
	<!-- Sidebar ================================================== -->
		<div id="sidebar" class="span3">
			<div class="well well-small">
			<?php				
				$cek = mysql_query("SELECT * FROM detailpesanan 
									INNER JOIN pemesanan
										ON detailpesanan.idPemesanan = pemesanan.idPemesanan
									INNER JOIN barang
										ON detailpesanan.idBarang = barang.idBarang
									WHERE pemesanan.idCustomer='$_SESSION[idCustomer]'
										AND pemesanan.statusPemesanan = 'Open'");
				$jumlah = mysql_num_rows($cek);
				$subtotal=0;
				while($rc = mysql_fetch_array($cek)){
					$subtotal =  $subtotal + ($rc['hargaBarang']*$rc['qtyDetailpesanan']);
				}
				if($jumlah==0){
					echo"
					<a id='myCart' href='detail.php?mod=pesananku'><img src='themes/images/ico-cart.png' alt='cart'>$jumlah item <span class='badge badge-warning pull-right'>Rp. 0</span></a>";
				}else{
					echo"<a id='myCart' href='detail.php?mod=pesananku'><img src='themes/images/ico-cart.png' alt='cart'>$jumlah item <span class='badge badge-warning pull-right'>Rp. $subtotal</span></a> ";
				}
			?>
			</div>
			<ul id="sideManu" class="nav nav-tabs nav-stacked">
				<li class="subMenu open"><a> Merek</a>
					<ul>
						<?php
							$merek = mysql_query("SELECT * FROM merek");
							while($m = mysql_fetch_array($merek)){
								echo"<li><a href='detail.php?mod=merek&id=$m[idMerek]'>$m[nameMerek]</a></li>";
							}		
						?>
					</ul>
				</li>
				
			</ul>
			<br/>
					
			<div class="thumbnail">
				<img src="themes/images/payment_methods.png" title="Bootshop Payment Methods" alt="Payments Methods">
				<div class="caption">
				  <h5>Metode Pembayaran</h5>
				</div>
			</div>
		</div>
	<!-- Sidebar end=============================================== -->
		
		<div class="span9">		
			<div class="well well-small">
				<h4>NEW PRODUK <small class="pull-right">Produk-produk Terbaru</small></h4>
				<div class="row-fluid">
				<div id="featured" class="carousel slide">
				<div class="carousel-inner">
					<div class="item active">
						<ul class="thumbnails">
							<?php
							$barang = mysql_query("SELECT * FROM detailpesanan 
													INNER JOIN barang 
														ON barang.idBarang = detailpesanan.idBarang 
													GROUP BY detailpesanan.idBarang
													ORDER BY barang.idBarang DESC LIMIT 0,4");
							while($br = mysql_fetch_array($barang)){									
								echo"								
								<li class='span3'>
								  <div class='thumbnail'>
									<i class='tag'></i>
									<a href='detail.php?id=$br[idBarang]'>
										<img src='master/images/$br[imgBarang]' alt='' />
									</a>
									<div class='caption'>
									  <h5>$br[nameBarang]<br/>
											Rp. $br[hargaBarang]
									  </h5>
									  <h4><a class='btn' href='detail.php?id=$br[idBarang]'>Lihat</a></h4>
									</div>
								  </div>
								</li>";
							}
							?>
						</ul>
					</div>
					<div class="item">
						<ul class="thumbnails">
							<?php
							$barang = mysql_query("SELECT * FROM barang ORDER BY idBarang LIMIT 4,4");
							while($br = mysql_fetch_array($barang)){									
								echo"								
								<li class='span3'>
								  <div class='thumbnail'>
									<i class='tag'></i>
									<a href='detail.php?id=$br[idBarang]'>
										<img src='master/images/$br[imgBarang]' alt='' />
									</a>
									<div class='caption'>
									  <h5>$br[nameBarang]<br/>
											Rp. $br[hargaBarang]
									  </h5>
									  <h4><a class='btn' href='detail.php?id=$br[idBarang]'>Lihat</a></h4>
									</div>
								  </div>
								</li>";
							}
							?>
						</ul>
					</div>
				  </div>
				  <a class="left carousel-control" href="#featured" data-slide="prev">‹</a>
				  <a class="right carousel-control" href="#featured" data-slide="next">›</a>
				  </div>
				  </div>
			</div>
			
			<h4>Produk Baru </h4>
			<ul class="thumbnails">
				<?php
					$barang = mysql_query("SELECT * FROM barang ORDER BY idBarang ");
					while($br = mysql_fetch_array($barang)){									
						echo"								
						<li class='span3'>
						  <div class='thumbnail'>
							<a href='detail.php?id=$br[idBarang]'>
								<img src='master/images/$br[imgBarang]' alt='' />
							</a>
							<div class='caption'>
							  <h5>$br[nameBarang]<br/>
									Rp. $br[hargaBarang]
							  </h5>
							  <h4><a class='btn' href='detail.php?id=$br[idBarang]'>Lihat</a></h4>
							</div>
						  </div>
						</li>";
					}
				?>
			</ul>
		</div>
		
	</div>
	</div>
</div>

<!------footer---->
<div  id="footerSection">
<div class="container">
	<div class="row">
		<div class="span3">
			<h5>ACCOUNT</h5>
			<a href="detail.php?mod=login">LOGIN</a>
			<a href="detail.php?mod=histori">ORDER HISTORY</a>
		 </div>
		<div class="span3">
			<h5>INFORMATION</h5>
			<a href="detail.php?mod=kontak">KONTAK</a>  
			<a href="detail.php?mod=kebijakan">KEBIJAKAN DAN PRIVASI</a> 
			<a href="detail.php?mod=faq">FAQ</a>
		 </div>
		<div id="socialMedia" class="span3 pull-right">
			<h5>SOCIAL MEDIA </h5>
			<a href="#"><img width="60" height="60" src="themes/images/facebook.png" title="facebook" alt="facebook"/></a>
			<a href="#"><img width="60" height="60" src="themes/images/twitter.png" title="twitter" alt="twitter"/></a>
			<a href="#"><img width="60" height="60" src="themes/images/youtube.png" title="youtube" alt="youtube"/></a>
		 </div> 
	 </div>
	<p>Disney COm © All rights Reseverd </p>
</div><!-- Container End -->
</div>

<script src="themes/js/jquery.js" type="text/javascript"></script>
<script src="themes/js/bootstrap.min.js" type="text/javascript"></script>
<script src="themes/js/google-code-prettify/prettify.js"></script>

<script src="themes/js/bootshop.js"></script>
<script src="themes/js/jquery.lightbox-0.5.js"></script>

</body>
</html>

